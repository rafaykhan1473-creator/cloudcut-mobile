import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path_provider/path_provider.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import 'analyze.dart';
import 'ff.dart';
import 'models.dart';
import 'planner.dart';
import 'render.dart';
import 'seo.dart';
import 'services.dart';

const _moodOf = {'happy': 'happy', 'sad': 'sad', 'fear': 'fear', 'surprise': 'surprise', 'excitement': 'excitement', 'neutral': 'neutral'};

Future<Directory> moviesDir() async {
  final docs = await getApplicationDocumentsDirectory();
  return Directory('${docs.path}/movies')..createSync(recursive: true);
}

class Pipeline {
  final ValueNotifier<Prog> prog = ValueNotifier(const Prog(0, 'Starting...'));
  final List<String> outputs = [];

  void _set(double v, String m) => prog.value = Prog(v.clamp(0.0, 1.0).toDouble(), m);

  Future<void> cancel() => FF.cancel();

  /// Poora autonomous edit: analyze -> story -> hook -> pacing/fx -> render (16:9 / 9:16) -> thumbnail + SEO.
  Future<void> run(List<String> paths, List<String> names, String projectName, Options o) async {
    FF.cancelled = false;
    await WakelockPlus.enable();
    Directory? work;
    try {
      final docs = await getApplicationDocumentsDirectory();
      final tmp = await getTemporaryDirectory();
      final out = await moviesDir();
      final stamp = DateTime.now().millisecondsSinceEpoch;
      work = Directory('${tmp.path}/work_$stamp')..createSync(recursive: true);
      final fonts = Directory('${docs.path}/fonts')..createSync(recursive: true);
      final ttf = File('${fonts.path}/DejaVuSans-Bold.ttf');
      if (!ttf.existsSync()) {
        ttf.writeAsBytesSync((await rootBundle.load('assets/DejaVuSans-Bold.ttf')).buffer.asUint8List());
      }
      await FF.setFonts(fonts.path);
      await FF.detectEncoder();
      final cfg = await FxConfig.load();
      final sv = Services();

      // 1) analyze every clip
      final ok = <Clip>[];
      final failed = <String>[];
      for (var i = 0; i < paths.length; i++) {
        _set(0.45 * i / paths.length, 'Analyzing clip ${i + 1} of ${paths.length}');
        try {
          ok.add(await analyzeClip(Clip(paths[i], names[i], i), work.path, sv));
        } catch (e) {
          if (FF.cancelled) rethrow; // kharab clip skip, lekin report mein dikhegi
          final msg = '$e'.replaceAll('Exception: ', '').replaceAll('\n', ' ');
          failed.add('${names[i]}: ${msg.length > 160 ? msg.substring(0, 160) : msg}');
        }
      }
      await sv.faces?.close();
      if (ok.isEmpty) throw Exception('Koi clip analyze nahi ho saki. Doosri videos try karein.');

      // 2) story: order -> hook -> roles -> pacing -> camera fx
      _set(0.46, 'AI is building your story');
      final cand = candidates(ok);
      final hr = extractHook(cand.segs, cand.secs);
      final fin = <Seg>[if (hr.hook != null) hr.hook!, ...mergeContiguous(hr.rest)];
      assignRoles(fin);
      applyPacing(fin, cand.secs);
      applyFx(fin);
      final dom = dominantEmotion(fin);
      final grade = gradeFor(dom);

      // AI report: har clip ke saath kya hua (phone par hi dikhta hai)
      double usedOf(Clip c) => fin.where((x) => identical(x.clip, c)).fold<double>(0, (a, x) => a + x.dur);
      final report = <String>[
        'Selected ${paths.length} clips • analyzed ${ok.length} • skipped ${failed.length}',
        for (final f in failed) 'X SKIPPED - $f',
        for (final c in ok)
          '- ${c.name} (${c.duration.toStringAsFixed(1)}s): movie mein ${usedOf(c).toStringAsFixed(1)}s'
              '${cand.notes[c] != null && cand.notes[c]!.isNotEmpty ? ' | ${cand.notes[c]!.join(', ')}' : ''}',
        'Story: ${fin.length} cuts • ${fin.where((x) => x.fx.isNotEmpty).length} effects • mood $dom • grade $grade',
        'Engine: encoder ${FF.vcodec}',
      ];

      // 3) narration only if needed (speech < 30%) and a brief exists
      final vo = <VoLine>[];
      final total = fin.fold<double>(0, (a, s) => a + s.dur);
      final spoken = fin.where((s) => segWords(s.clip, s.start, s.end).length >= 3).fold<double>(0, (a, s) => a + s.dur);
      if (o.narration && o.brief.trim().isNotEmpty && total > 0 && spoken / total < 0.30) {
        _set(0.48, 'Creating narration');
        final lines = sentences(o.brief).take(10).toList();
        final quiet = fin.where((s) => !s.isHook && segWords(s.clip, s.start, s.end).length < 3 && s.dur >= 2.0).toList();
        final used = <String>{};
        for (var i = 0; i < lines.length && quiet.isNotEmpty; i++) {
          final seg = quiet[(i * (quiet.length - 1) / (lines.length > 1 ? lines.length - 1 : 1)).round()];
          if (!used.add(seg.sid)) continue;
          final p = await sv.narrator.synth(lines[i], o.lang, 'cc_vo_${stamp}_$i.wav');
          if (p == null) break;
          final info = await FF.probe(p);
          final d = double.tryParse('${(info['format'] as Map?)?['duration']}') ?? 0;
          if (d > 0) vo.add(VoLine(seg.sid, p, d));
        }
      }

      // 4) SEO text
      final transcript = ok.map((c) => c.words.map((w) => w.w).join(' ')).join(' ');
      final meta = buildMeta(projectName, o.brief, transcript, dom);

      // 5) render each requested format
      final jobs = <String>[if (o.movie169) '16:9', if (o.shorts) '9:16'];
      for (var j = 0; j < jobs.length; j++) {
        final aspect = jobs[j];
        final lo = 0.5 + 0.48 * j / jobs.length, hi = 0.5 + 0.48 * (j + 1) / jobs.length;
        final label = aspect == '16:9' ? 'YouTube movie' : 'Shorts';
        _set(lo, 'Rendering $label...');
        final segs = aspect == '9:16' ? fitToDuration(fin, 59.0) : fin;
        final sub = Directory('${work.path}/r$j')..createSync(recursive: true);
        final f = await renderMovie(
          segs: segs, aspect: aspect, hd: o.hd, work: sub.path, grade: grade, mood: _moodOf[dom] ?? 'neutral',
          cfg: cfg, fontsDir: fonts.path, musicPath: o.musicPath, vo: vo,
          onProgress: (p) => _set(lo + (hi - lo) * p, 'Rendering $label... ${(p * 100).round()}%'),
        );
        final safe = projectName.replaceAll(RegExp(r'[^A-Za-z0-9_-]+'), '_');
        final base = '${out.path}/${safe}_${stamp}_${aspect == '16:9' ? '16x9' : '9x16'}';
        File(f).copySync('$base.mp4');
        try {
          await makeThumbnail(segs, aspect, meta.thumbText, ttf.path, sub.path, '$base.jpg');
        } catch (_) {}
        File('$base.json').writeAsStringSync(jsonEncode({
          'aspect': aspect, 'mood': dom, 'grade': grade, 'segments': segs.length,
          'effects': segs.where((s) => s.fx.isNotEmpty).length, 'narration': vo.isNotEmpty, 'report': report, ...meta.toJson()
        }));
        outputs.add('$base.mp4');
        File(f).deleteSync();
        _set(hi, 'Finished $label');
      }
      _set(1, 'Done!');
    } finally {
      FF.onTime(null);
      await WakelockPlus.disable();
      try {
        work?.deleteSync(recursive: true);
      } catch (_) {}
    }
  }
}
