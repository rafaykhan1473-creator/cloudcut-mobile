import 'models.dart';

const _stop = {
  'the', 'and', 'for', 'that', 'this', 'with', 'you', 'your', 'was', 'were', 'are', 'from', 'have', 'has', 'had', 'been', 'would',
  'could', 'should', 'about', 'into', 'over', 'under', 'again', 'very', 'more', 'most', 'than', 'also', 'them', 'these', 'those',
  'what', 'which', 'when', 'where', 'there', 'here', 'dont', 'cant', 'just', 'like', 'will', 'then', 'they', 'their', 'not', 'but',
  'hai', 'hain', 'aur', 'yeh', 'woh', 'nahi', 'nahin', 'kya', 'bhi', 'main', 'mein', 'tum', 'hum'
};
const _tagline = {
  'excitement': "You Won't Believe This", 'sad': 'A Story That Hits Hard', 'fear': 'Wait Until You See This',
  'surprise': 'Unexpected Moment', 'happy': 'A Feel-Good Story', 'neutral': 'The Full Story'
};
const _chip = {
  'excitement': 'WAIT FOR IT', 'sad': 'HEARTBREAKING', 'fear': 'WATCH THIS', 'surprise': 'UNEXPECTED', 'happy': 'SO GOOD', 'neutral': 'THE STORY'
};

List<String> keywords(String text, String brief, [int n = 8]) {
  final c = <String, int>{};
  void add(String t, int wgt) {
    for (final m in RegExp(r"[A-Za-z][A-Za-z']{3,}").allMatches(t.toLowerCase())) {
      final w = m.group(0)!;
      if (!_stop.contains(w)) c[w] = (c[w] ?? 0) + wgt;
    }
  }

  add(text, 1);
  add(brief, 3);
  final e = c.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  return e.take(n).map((x) => x.key).toList();
}

List<String> sentences(String t) =>
    t.trim().split(RegExp(r'(?<=[.!?])\s+')).map((s) => s.trim()).where((s) => s.length > 3).toList();

String _title(String w) => w.isEmpty ? w : w[0].toUpperCase() + w.substring(1);

Meta buildMeta(String name, String brief, String transcript, String emotion) {
  final kws = keywords(transcript, brief);
  final isDefault = name.trim().isEmpty || name.toLowerCase() == 'my movie';
  final sents = sentences(brief);
  var base = sents.isNotEmpty ? sents.first : (isDefault && kws.isNotEmpty ? kws.take(3).map(_title).join(' ') : name);
  base = base.replaceAll(RegExp(r'[.!?]+$'), '');
  var title = '$base | ${_tagline[emotion] ?? _tagline['neutral']}';
  if (title.length > 70) title = '${base.substring(0, base.length < 67 ? base.length : 67).trim()}...';
  final core = brief.isNotEmpty ? brief : (sentences(transcript).take(2).join(' '));
  final desc = '${core.isEmpty ? '$name - an edited story.' : core}\n\nWatch till the end.\n\nEdited automatically with CloudCut.';
  final raw = [
    ...kws.take(6).map((w) => '#${_title(w.replaceAll(RegExp(r"\W"), ""))}'),
    emotion == 'neutral' ? '#Story' : '#${_title(emotion)}',
    '#Cinematic', '#Storytime', '#YouTube'
  ];
  final seen = <String>{};
  final tags = <String>[];
  for (final t in raw) {
    if (t.length > 2 && seen.add(t.toLowerCase())) tags.add(t);
  }
  final m = Meta();
  m.title = title;
  m.description = desc.length > 1000 ? desc.substring(0, 1000) : desc;
  m.hashtags = tags.take(12).toList();
  m.thumbText = (kws.isNotEmpty && brief.isEmpty ? kws.take(2).map((w) => w.toUpperCase()).join(' ') : (_chip[emotion] ?? 'THE STORY'));
  m.shortsTitle = '${title.length > 52 ? title.substring(0, 52).trim() : title} #Shorts';
  m.shortsHashtags = [...tags.take(10), '#Shorts'];
  return m;
}
