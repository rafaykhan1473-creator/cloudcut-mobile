/// Animated karaoke captions (ASS): pop-in + word highlight; important words bade.
String _t(double x) {
  final v = x < 0 ? 0.0 : x;
  final h = v ~/ 3600, m = (v % 3600) ~/ 60, s = v % 60;
  return '$h:${m.toString().padLeft(2, '0')}:${s.toStringAsFixed(2).padLeft(5, '0')}';
}

String _esc(String w) => w.replaceAll(RegExp(r'[{}\\]'), '').toUpperCase();

class CapWord {
  final String w;
  final double s, e;
  final bool em;
  CapWord(this.w, this.s, this.e, this.em);
}

String buildAss(List<CapWord> words, int W, int H) {
  final portrait = H > W;
  final fs = portrait ? (W * 0.085).round() : (H * 0.06).round();
  final marginV = portrait ? (H * 0.20).round() : (H * 0.08).round();
  final perLine = portrait ? 3 : 5;
  final outline = fs ~/ 14 < 3 ? 3 : fs ~/ 14;
  final sb = StringBuffer();
  sb.writeln('[Script Info]\nScriptType: v4.00+\nPlayResX: $W\nPlayResY: $H\nWrapStyle: 2\n');
  sb.writeln('[V4+ Styles]');
  sb.writeln('Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding');
  sb.writeln('Style: Cap,DejaVu Sans,$fs,&H0000E5FF,&H00FFFFFF,&H00000000,&H80000000,1,0,0,0,100,100,0,0,1,$outline,2,2,40,40,$marginV,1\n');
  sb.writeln('[Events]');
  sb.writeln('Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text');
  final chunk = <CapWord>[];
  void flush() {
    if (chunk.isEmpty) return;
    final start = chunk.first.s, end = chunk.last.e + 0.12;
    final parts = <String>[];
    for (var i = 0; i < chunk.length; i++) {
      final w = chunk[i];
      final nxt = i + 1 < chunk.length ? chunk[i + 1].s : w.e;
      final cs = ((nxt - w.s) * 100).round();
      var word = _esc(w.w);
      if (w.em) word = '{\\fscx118\\fscy118}$word{\\fscx100\\fscy100}';
      parts.add('{\\k${cs < 1 ? 1 : cs}}$word');
    }
    const pop = '{\\fad(60,40)\\fscx85\\fscy85\\t(0,120,\\fscx100\\fscy100)}';
    sb.writeln('Dialogue: 0,${_t(start)},${_t(end)},Cap,,0,0,0,,$pop${parts.join(' ')}');
    chunk.clear();
  }

  for (final w in words) {
    if (chunk.isNotEmpty &&
        (chunk.length >= perLine || w.s - chunk.last.e > 0.6 || RegExp(r'[.!?]$').hasMatch(chunk.last.w))) {
      flush();
    }
    chunk.add(w);
  }
  flush();
  return sb.toString();
}
