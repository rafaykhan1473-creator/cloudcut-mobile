import 'dart:math' as math;
import 'models.dart';

const double minSeg = 1.0;

// ---------------------------------------------------------------- scoring
List<double> secScores(Clip c) {
  final n = c.timeline.length;
  final wps = List<int>.filled(n, 0);
  for (final w in c.words) {
    final i = w.s.floor();
    if (i >= 0 && i < n) wps[i]++;
  }
  final q = 0.5 + 0.5 * c.quality;
  return List.generate(n, (i) {
    final t = c.timeline[i];
    return (0.25 * math.min(wps[i] / 3, 1.0) + 0.20 * math.min(t.face, 1.0) + 0.15 * math.min(t.motion * 8, 1.0) +
            0.15 * t.ei + 0.10 * t.sharp + 0.15 * t.rms) * q;
  });
}

double mean(List<double> a, double s, double e) {
  final lo = s.floor(), hi = math.min(a.length, e.ceil());
  if (lo < 0 || lo >= hi) return 0;
  var sum = 0.0;
  for (var i = lo; i < hi; i++) {
    sum += a[i];
  }
  return sum / (hi - lo);
}

List<Word> segWords(Clip c, double s, double e) => c.words.where((w) => w.s >= s && w.e <= e).toList();

// ---------------------------------------------------------------- bad / silent removal
List<List<double>> _merge(List<List<double>> iv) {
  final s = List<List<double>>.of(iv)..sort((a, b) => a[0].compareTo(b[0]));
  final out = <List<double>>[];
  for (final x in s) {
    if (out.isNotEmpty && x[0] <= out.last[1]) {
      out.last[1] = math.max(out.last[1], x[1]);
    } else {
      out.add([x[0], x[1]]);
    }
  }
  return out;
}

/// >=2s blurry / too-dark runs. Important dialogue wale hisse bachaye jate hain.
List<List<double>> badIntervals(Clip c) {
  final tl = c.timeline;
  if (tl.isEmpty) return [];
  final sh = tl.map((t) => t.sharp).toList()..sort();
  final thr = math.max(0.04, 0.35 * sh[sh.length ~/ 2]);
  final runs = <List<double>>[];
  int? start;
  for (var i = 0; i <= tl.length; i++) {
    final bad = i < tl.length && (tl[i].sharp < thr || tl[i].luma < 0.05);
    if (bad && start == null) start = i;
    if (!bad && start != null) {
      if (i - start >= 2) runs.add([start.toDouble(), i.toDouble()]);
      start = null;
    }
  }
  return runs.where((r) => !c.sentences.any((x) => x.important && x.s < r[1] && x.e > r[0])).toList();
}

List<List<double>> keepSegments(Clip c) {
  var pad = 0.15;
  final dur = c.duration;
  final bad = badIntervals(c);
  final removed = _merge([...(c.hasAudio ? c.silences : <List<double>>[]), ...bad]);
  var cur = 0.0;
  var raw = <List<double>>[];
  for (final r in removed) {
    if (r[0] > cur) raw.add([cur, r[0]]);
    cur = math.max(cur, r[1]);
  }
  if (cur < dur) raw.add([cur, dur]);
  if (!c.hasAudio) {
    raw = raw.map((r) => [r[0], math.min(r[1], r[0] + 10.0)]).toList();
    pad = 0;
  }
  final out = <List<double>>[];
  for (final r in raw) {
    final s = math.max(0.0, r[0] - pad), e = math.min(dur, r[1] + pad);
    if (out.isNotEmpty && s - out.last[1] < 0.3) {
      out.last[1] = e;
    } else {
      out.add([s, e]);
    }
  }
  final kept = out.where((r) => r[1] - r[0] >= minSeg).toList();
  final badCov = bad.fold<double>(0, (a, r) => a + r[1] - r[0]);
  if (kept.isEmpty && c.hasAudio && dur >= minSeg && badCov < 0.7 * dur && (c.faceRatio > 0.3 || c.motion > 0.03)) {
    return [
      [0.0, math.min(dur, 6.0)]
    ];
  }
  return kept;
}

// ---------------------------------------------------------------- ordering
int _nat(String a, String b) {
  final re = RegExp(r'(\d+|\D+)');
  final ta = re.allMatches(a.toLowerCase()).map((m) => m.group(0)!).toList();
  final tb = re.allMatches(b.toLowerCase()).map((m) => m.group(0)!).toList();
  for (var i = 0; i < math.min(ta.length, tb.length); i++) {
    final na = int.tryParse(ta[i]), nb = int.tryParse(tb[i]);
    final r = (na != null && nb != null) ? na.compareTo(nb) : ta[i].compareTo(tb[i]);
    if (r != 0) return r;
  }
  return ta.length.compareTo(tb.length);
}

/// Shooting order: creation_time -> filename numbers -> picker order.
Map<Clip, int> clipOrder(List<Clip> clips) {
  final byTime = clips.every((c) => c.creationTime != null) && clips.map((c) => c.creationTime).toSet().length > 1;
  final hasDigits = clips.any((c) => RegExp(r'\d').hasMatch(c.name));
  int cmp(Clip a, Clip b) {
    if (byTime) {
      final r = a.creationTime!.compareTo(b.creationTime!);
      if (r != 0) return r;
    } else if (hasDigits) {
      final r = _nat(a.name, b.name);
      if (r != 0) return r;
    }
    return a.position.compareTo(b.position);
  }

  final s = List<Clip>.of(clips)..sort(cmp);
  return {for (var i = 0; i < s.length; i++) s[i]: i};
}

// ---------------------------------------------------------------- candidates + dedupe
int _hamming(String a, String b) {
  var d = 0;
  for (var i = 0; i < math.min(a.length, b.length); i++) {
    var x = int.parse(a[i], radix: 16) ^ int.parse(b[i], radix: 16);
    while (x > 0) {
      d += x & 1;
      x >>= 1;
    }
  }
  return d;
}

bool _visualDup(List<String> a, List<String> b) {
  if (a.isEmpty || b.isEmpty) return false;
  var hit = 0;
  for (final x in a) {
    if (b.any((y) => _hamming(x, y) <= 6)) hit++;
  }
  return hit / a.length >= 0.7;
}

double _jaccard(String a, String b) {
  final sa = a.split(' ').toSet(), sb = b.split(' ').toSet();
  final i = sa.intersection(sb).length, u = sa.union(sb).length;
  return u == 0 ? 0 : i / u;
}

String _segText(Clip c, double s, double e) =>
    segWords(c, s, e).map((w) => w.w.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '')).where((x) => x.isNotEmpty).join(' ');

List<String> _segHashes(Clip c, double s, double e, [int cap = 10]) {
  final hs = c.hashes.where((h) => h.t >= s && h.t < e).map((h) => h.h).toList();
  if (hs.length <= cap) return hs;
  final step = hs.length / cap;
  return [for (var i = 0; i < cap; i++) hs[(i * step).floor()]];
}

class Candidates {
  final List<Seg> segs;
  final Map<Clip, List<double>> secs;
  Candidates(this.segs, this.secs);
}

Candidates candidates(List<Clip> clips) {
  final rank = clipOrder(clips);
  final secs = <Clip, List<double>>{};
  final all = <Seg>[];
  final sorted = List<Clip>.of(clips)..sort((a, b) => rank[a]!.compareTo(rank[b]!));
  for (final c in sorted) {
    final sc = secs[c] = secScores(c);
    for (final r in keepSegments(c)) {
      final sg = Seg(c, double.parse(r[0].toStringAsFixed(2)), double.parse(r[1].toStringAsFixed(2)));
      sg.important = c.sentences.any((x) => x.important && x.s < sg.end && x.e > sg.start);
      sg.score = mean(sc, sg.start, sg.end) + (sg.important ? 0.3 : 0.0);
      sg.text = _segText(c, sg.start, sg.end);
      sg.hashes = _segHashes(c, sg.start, sg.end);
      sg.emotion = c.emotion;
      sg.intensity = c.intensity;
      all.add(sg);
    }
  }
  final kept = <Seg>[];
  for (final sg in all) {
    Seg? dup;
    for (final k in kept) {
      if (sg.text.length >= 25 && k.text.length >= 25 && _jaccard(sg.text, k.text) > 0.8) {
        dup = k;
      } else if (!identical(k.clip, sg.clip) && sg.text.length < 10 && k.text.length < 10 && _visualDup(sg.hashes, k.hashes)) {
        dup = k;
      }
      if (dup != null) break;
    }
    if (dup == null) {
      kept.add(sg);
    } else if (sg.score > dup.score) {
      kept[kept.indexOf(dup)] = sg; // best take rakho
    }
  }
  if (kept.isEmpty) throw Exception('Koi usable footage nahi mili (clips khamosh/dhundli hain)');
  kept.sort((a, b) {
    final r = rank[a.clip]!.compareTo(rank[b.clip]!);
    return r != 0 ? r : a.start.compareTo(b.start);
  });
  for (var i = 0; i < kept.length; i++) {
    kept[i].sid = 's$i';
  }
  return Candidates(kept, secs);
}

// ---------------------------------------------------------------- hook
class HookResult {
  final Seg? hook;
  final List<Seg> rest;
  HookResult(this.hook, this.rest);
}

HookResult extractHook(List<Seg> ordered, Map<Clip, List<double>> secs) {
  var bestScore = -1.0;
  int? bi;
  double bs = 0, be = 0;
  for (var i = 0; i < ordered.length; i++) {
    final sg = ordered[i];
    final w = math.min(5.0, sg.end - sg.start);
    if (w < 2.5) continue;
    final sc = secs[sg.clip]!;
    var t = sg.start;
    while (t + w <= sg.end + 1e-6) {
      var s = mean(sc, t, t + w);
      if (sg.clip.words.any((x) => x.s >= t && x.s <= t + 0.5)) s += 0.05;
      if (s > bestScore) {
        bestScore = s;
        bi = i;
        bs = t;
        be = t + w;
      }
      t += 1.0;
    }
  }
  if (bi == null) return HookResult(null, ordered);
  final src = ordered[bi];
  final hook = src.copy()
    ..sid = 'hook'
    ..start = double.parse(bs.toStringAsFixed(2))
    ..end = double.parse(be.toStringAsFixed(2))
    ..score = bestScore + 1
    ..isHook = true
    ..role = 'hook';
  final pieces = <Seg>[];
  for (final r in [
    [src.start, bs],
    [be, src.end]
  ]) {
    if (r[1] - r[0] >= minSeg) {
      final p = src.copy()
        ..start = double.parse(r[0].toStringAsFixed(2))
        ..end = double.parse(r[1].toStringAsFixed(2))
        ..score = mean(secs[src.clip]!, r[0], r[1]);
      pieces.add(p);
    }
  }
  return HookResult(hook, [...ordered.sublist(0, bi), ...pieces, ...ordered.sublist(bi + 1)]);
}

List<Seg> mergeContiguous(List<Seg> segs) {
  final out = <Seg>[];
  for (final s in segs) {
    if (out.isNotEmpty && identical(out.last.clip, s.clip) && s.start - out.last.end >= 0 && s.start - out.last.end < 0.3) {
      out.last.end = s.end;
      out.last.score = math.max(out.last.score, s.score);
    } else {
      out.add(s.copy());
    }
  }
  return out;
}

// ---------------------------------------------------------------- 3-act roles
void assignRoles(List<Seg> fin) {
  final body = fin.where((s) => !s.isHook).toList();
  final n = body.length;
  final win = [for (var i = 0; i < n; i++) if (i / math.max(n - 1, 1) >= 0.6 && i / math.max(n - 1, 1) <= 0.9) i];
  win.sort((a, b) => (body[b].intensity * (0.5 + body[b].score)).compareTo(body[a].intensity * (0.5 + body[a].score)));
  final climax = win.take(n >= 8 ? 2 : 1).toSet();
  for (var i = 0; i < n; i++) {
    final r = i / math.max(n - 1, 1);
    body[i].role = climax.contains(i) ? 'climax' : (r < 0.15 ? 'setup' : (r > 0.9 ? 'resolution' : 'rising'));
  }
}

// ---------------------------------------------------------------- cinematic pacing
const _baseLen = {'excitement': 2.8, 'surprise': 3.0, 'fear': 3.2, 'happy': 4.0, 'sad': 6.0, 'neutral': 4.5};
const _roleMul = {'hook': 1.0, 'setup': 1.2, 'rising': 0.9, 'climax': 0.75, 'resolution': 1.3, 'broll': 1.0};

double _targetLen(Seg s) {
  final t = (_baseLen[s.emotion] ?? 4.5) * (1.3 - 0.6 * s.intensity) * (_roleMul[s.role] ?? 1.0);
  return math.max(1.6, math.min(9.0, t));
}

void _trim(Seg sg, List<double> secs) {
  final d = sg.dur, tgt = _targetLen(sg);
  if (sg.isHook || sg.important || d <= tgt * 1.35) return;
  final words = segWords(sg.clip, sg.start, sg.end);
  final spoken = words.length >= 3;
  if (spoken && d <= tgt * 1.8) return; // speech beech mein na kaato
  var best = -1.0, bt = sg.start;
  var t = sg.start;
  while (t + tgt <= sg.end + 1e-6) {
    final sc = mean(secs, t, t + tgt);
    if (sc > best) {
      best = sc;
      bt = t;
    }
    t += 0.5;
  }
  var s = bt, e = bt + tgt;
  if (spoken) {
    final starts = words.where((w) => w.s >= s - 0.3 && w.s <= e - 0.5).map((w) => w.s).toList();
    if (starts.isNotEmpty) s = starts.reduce(math.min);
    final ends = words.where((w) => w.s >= s && w.e <= e + 0.6).map((w) => w.e).toList();
    if (ends.isNotEmpty) e = ends.reduce(math.max);
    s = math.max(sg.start, s - 0.1);
    e = math.min(sg.end, e + 0.15);
  }
  if (e - s >= 1.0) {
    sg.start = double.parse(s.toStringAsFixed(2));
    sg.end = double.parse(e.toStringAsFixed(2));
  }
}

List<dynamic> _transition(Seg prev, Seg sg, int j) {
  if (identical(prev.clip, sg.clip)) return ['fade', 0.12];
  final emo = sg.emotion, inten = sg.intensity;
  if (inten >= 0.7 && (emo == 'excitement' || emo == 'happy')) return j % 2 == 1 ? ['slideleft', 0.25] : ['fade', 0.1];
  if (emo == 'surprise') return ['fadewhite', 0.2];
  if (emo == 'fear') return ['fadeblack', 0.15];
  if (emo == 'sad') return inten >= 0.5 ? ['fadeblack', 0.8] : ['dissolve', 0.6];
  if (emo == 'happy') return j % 2 == 1 ? ['dissolve', 0.4] : ['slideleft', 0.35];
  if (emo == 'excitement') return ['wipeleft', 0.2];
  return ['fade', 0.4];
}

void applyPacing(List<Seg> segs, Map<Clip, List<double>> secs) {
  for (final s in segs) {
    _trim(s, secs[s.clip]!);
  }
  for (var j = 1; j < segs.length; j++) {
    final t = _transition(segs[j - 1], segs[j], j);
    segs[j].transition = t[0] as String;
    final td = t[1] as double;
    segs[j].td = math.max(0.08, math.min(td, math.min(0.45 * segs[j - 1].dur, 0.45 * segs[j].dur)));
  }
}

// ---------------------------------------------------------------- camera effects (only where they help)
double outDur(double d, Map<String, dynamic>? speed) {
  if (speed == null) return d;
  if (speed['mode'] == 'slowmo') return d / (speed['factor'] as double);
  final k = speed['k'] as double;
  return d / k * math.log(1 + k);
}

void applyFx(List<Seg> segs) {
  final cap = math.max(1, (0.3 * segs.length).floor());
  var used = 0, panDir = 1.0;
  for (final sg in segs) {
    final c = sg.clip;
    final dialog = segWords(c, sg.start, sg.end).length >= 3;
    final tl = c.timeline.sublist(math.min(c.timeline.length, sg.start.floor()), math.min(c.timeline.length, math.max(sg.start.floor() + 1, sg.end.ceil())));
    final face = tl.isEmpty ? 0.0 : tl.map((t) => t.face).reduce((a, b) => a + b) / tl.length;
    final fx = <String, dynamic>{};
    if (sg.isHook) {
      fx['zoom'] = {'dir': 'in', 'amt': 0.08};
    } else if (dialog && face > 0.5 && sg.dur >= 2.5 && (sg.intensity >= 0.5 || sg.role == 'climax')) {
      fx['zoom'] = {'dir': 'in', 'amt': 0.10};
    } else if (sg.role == 'resolution' && sg.dur >= 3.0) {
      fx['zoom'] = {'dir': 'out', 'amt': 0.10};
    } else if (!dialog && sg.dur >= 3.5 && c.motion < 0.03 && c.width >= c.height && face < 0.3) {
      fx['pan'] = {'amt': 0.9 * panDir};
      panDir = -panDir;
    }
    if (!dialog && !sg.isHook && used < cap) {
      if (sg.dur <= 2.5 && c.action == 'high' && (sg.role == 'climax' || sg.role == 'rising') && sg.intensity >= 0.7) {
        fx['speed'] = {'mode': 'slowmo', 'factor': 0.5};
        used++;
      } else if (sg.dur >= 3.0 && (c.action == 'high' || c.action == 'medium') && (sg.role == 'rising' || sg.role == 'climax') && sg.intensity >= 0.6) {
        fx['speed'] = {'mode': 'ramp', 'k': 0.8};
        used++;
      }
    }
    sg.fx = fx;
    sg.outDur = double.parse(outDur(sg.dur, fx['speed'] as Map<String, dynamic>?).toStringAsFixed(3));
  }
  for (var j = 1; j < segs.length; j++) {
    segs[j].td = math.max(0.08, math.min(segs[j].td, math.min(0.45 * segs[j - 1].od, 0.45 * segs[j].od)));
  }
}

List<Seg> fitToDuration(List<Seg> segs, double? maxTotal) {
  final total = segs.fold<double>(0, (a, s) => a + s.od);
  if (maxTotal == null || total <= maxTotal) return segs;
  final keep = <int>{};
  var used = 0.0;
  if (segs.isNotEmpty && segs[0].isHook) {
    keep.add(0);
    used = segs[0].od;
  }
  final idx = List<int>.generate(segs.length, (i) => i)..sort((a, b) => segs[b].score.compareTo(segs[a].score));
  for (final i in idx) {
    if (keep.contains(i)) continue;
    if (used + segs[i].od <= maxTotal) {
      keep.add(i);
      used += segs[i].od;
    }
  }
  final out = (keep.toList()..sort()).map((i) => segs[i]).toList();
  if (out.isEmpty) {
    final s = segs[0].copy()
      ..end = segs[0].start + maxTotal
      ..outDur = null
      ..fx = {};
    return [s];
  }
  return out;
}

String dominantEmotion(List<Seg> segs) {
  final acc = <String, double>{};
  for (final s in segs) {
    if (s.emotion != 'neutral') acc[s.emotion] = (acc[s.emotion] ?? 0) + s.dur * s.intensity;
  }
  if (acc.isEmpty) return 'neutral';
  return acc.entries.reduce((a, b) => a.value >= b.value ? a : b).key;
}

String gradeFor(String emotion) =>
    const {'happy': 'warm', 'excitement': 'punchy', 'sad': 'cool', 'fear': 'cool', 'surprise': 'cinematic', 'neutral': 'cinematic'}[emotion] ?? 'cinematic';
