import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/services.dart' show rootBundle;
import 'captions.dart';
import 'ff.dart';
import 'models.dart';
import 'planner.dart' show segWords;

class FxConfig {
  final Map<String, dynamic> j;
  FxConfig(this.j);
  static Future<FxConfig> load() async =>
      FxConfig(jsonDecode(await rootBundle.loadString('assets/fx.json')) as Map<String, dynamic>);
  String grade(String n) {
    final g = j['grades'] as Map<String, dynamic>;
    return (g[n] ?? g['cinematic']) as String;
  }

  List<String> get transitions => (j['transitions'] as List).cast<String>();
}

class VoLine {
  final String sid, path;
  final double dur;
  VoLine(this.sid, this.path, this.dur);
}

const _groupSize = 6; // phone RAM ke liye chhote groups

(int, int) sizeFor(String aspect, bool hd) {
  if (aspect == '16:9') return hd ? (1920, 1080) : (1280, 720);
  return hd ? (1080, 1920) : (720, 1280);
}

String _exposure(Clip a) {
  final b = math.max(-0.08, math.min(0.12, (0.45 - a.luma) * 0.5));
  var f = 'eq=brightness=${b.toStringAsFixed(3)}:contrast=1.04';
  if (a.sharp < 0.35) f += ',unsharp=5:5:0.6';
  return f;
}

String _vgraph(Clip a, int W, int H, String grade, Map<String, dynamic> fx, double d, double od, FxConfig cfg) {
  final sp = fx['speed'] as Map<String, dynamic>?;
  var pre = 'setpts=PTS-STARTPTS';
  if (sp != null && sp['mode'] == 'slowmo') {
    pre += ',setpts=${(1 / (sp['factor'] as double)).toStringAsFixed(3)}*PTS';
  } else if (sp != null) {
    final k = sp['k'] as double;
    final dd = d.toStringAsFixed(4);
    pre += ",setpts='($dd/$k)*log(1+$k*T/$dd)/TB'";
  }
  final srcAr = a.width / a.height, dstAr = W / H;
  String core;
  if ((srcAr - dstAr).abs() / dstAr < 0.05) {
    core = '[0:v]$pre,scale=$W:$H:flags=bilinear,setsar=1[b]';
  } else if (dstAr < srcAr) {
    // landscape -> portrait: face-follow crop
    final cx = a.faceCx >= 0 ? a.faceCx : 0.5;
    core = "[0:v]$pre,scale=$W:$H:force_original_aspect_ratio=increase:flags=bilinear,"
        "crop=$W:$H:'min(max(${cx.toStringAsFixed(3)}*iw-$W/2,0),iw-$W)':0,setsar=1[b]";
  } else {
    // portrait -> landscape: blurred background fit
    core = '[0:v]$pre,split=2[a][c];[a]scale=$W:$H:force_original_aspect_ratio=increase,crop=$W:$H,boxblur=20:3[bg];'
        '[c]scale=$W:$H:force_original_aspect_ratio=decrease[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,setsar=1[b]';
  }
  final chain = <String>[_exposure(a), cfg.grade(grade)];
  final z = fx['zoom'] as Map<String, dynamic>?;
  final pan = fx['pan'] as Map<String, dynamic>?;
  final ods = od.toStringAsFixed(3);
  if (z != null) {
    final amt = z['amt'];
    final f = z['dir'] == 'in' ? '(1+$amt*t/$ods)' : '(1+$amt*(1-t/$ods))';
    chain.add("scale=w='trunc(iw*$f/2)*2':h='trunc(ih*$f/2)*2':eval=frame:flags=bilinear,crop=$W:$H");
  } else if (pan != null) {
    final p = (pan['amt'] as double).toStringAsFixed(2);
    chain.add("scale=trunc(iw*1.12/2)*2:trunc(ih*1.12/2)*2:flags=bilinear,"
        "crop=$W:$H:x='(iw-$W)/2+(iw-$W)*$p*(t/$ods-0.5)':y='(ih-$H)/2'");
  }
  chain.add('fps=30');
  return '$core;[b]${chain.join(',')}[v]';
}

Future<void> _prep(Seg sg, int W, int H, String grade, FxConfig cfg, String out) async {
  final a = sg.clip;
  final d = sg.dur, od = sg.od;
  final sp = sg.fx['speed'] as Map<String, dynamic>?;
  final args = <String>['-ss', sg.start.toStringAsFixed(3), '-t', d.toStringAsFixed(3), '-i', a.path];
  final silent = !a.hasAudio || (sp != null && sp['mode'] == 'ramp');
  String af, amap;
  if (silent) {
    args.addAll(['-f', 'lavfi', '-t', od.toStringAsFixed(3), '-i', 'anullsrc=r=48000:cl=stereo']);
    amap = '1:a:0';
    af = 'aresample=48000,aformat=channel_layouts=stereo';
  } else {
    amap = '0:a:0';
    final l = <String>['aresample=48000', 'aformat=channel_layouts=stereo'];
    if (sp != null) l.add('atempo=0.5');
    // har clip ka dialogue ~ -20 dBFS par (balanced) + click-free edges
    l.addAll([
      'volume=${a.gainDb.toStringAsFixed(1)}dB',
      'alimiter=limit=0.95',
      'afade=t=in:d=0.03',
      'afade=t=out:st=${math.max(0.0, od - 0.04).toStringAsFixed(3)}:d=0.04'
    ]);
    af = l.join(',');
  }
  args.addAll([
    '-filter_complex', _vgraph(a, W, H, grade, sg.fx, d, od, cfg), '-map', '[v]', '-map', amap, '-af', af,
    ...FF.venc('ultrafast', '20'), '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '160k', '-ar', '48000', '-t', od.toStringAsFixed(3), out
  ]);
  await FF.run(args);
}

Future<void> _xfadeJoin(List<String> files, List<double> durs, List<double> tds, List<String> trans, String out) async {
  if (files.length == 1) {
    File(files[0]).renameSync(out);
    return;
  }
  final args = <String>[];
  for (final f in files) {
    args.addAll(['-i', f]);
  }
  final vf = <String>[], af = <String>[];
  var L = durs[0];
  var vl = '[0:v]', al = '[0:a]';
  for (var j = 1; j < files.length; j++) {
    vf.add('$vl[$j:v]xfade=transition=${trans[j]}:duration=${tds[j].toStringAsFixed(3)}:offset=${(L - tds[j]).toStringAsFixed(3)}[v$j]');
    af.add('$al[$j:a]acrossfade=d=${tds[j].toStringAsFixed(3)}[a$j]');
    vl = '[v$j]';
    al = '[a$j]';
    L = L + durs[j] - tds[j];
  }
  args.addAll([
    '-filter_complex', [...vf, ...af].join(';'), '-map', vl, '-map', al, '-r', '30',
    ...FF.venc('ultrafast', '20'), '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '160k', out
  ]);
  await FF.run(args);
}

List<List<int>> _groups(int n, List<double> tds) {
  final groups = <List<int>>[];
  var i = 0;
  while (i < n) {
    var end = math.min(i + _groupSize, n);
    if (end < n) {
      var best = end, bt = tds[end];
      for (var j = math.max(i + 2, end - 3); j <= end; j++) {
        if (tds[j] < bt) {
          bt = tds[j];
          best = j;
        }
      }
      end = best; // hard-cut sabse chhoti transition par
    }
    groups.add([for (var k = i; k < end; k++) k]);
    i = end;
  }
  return groups;
}

List<List<dynamic>> _sfxEvents(List<Seg> segs, List<double> segStart, List<double> tds, List<String> trans, Set<int> hard, double total) {
  final ev = <List<dynamic>>[];
  if (segs.isNotEmpty && segs[0].isHook) ev.add([0.0, 'impact', 0.45]);
  for (var j = 1; j < segs.length; j++) {
    final t0 = segStart[j], td = tds[j], tr = trans[j];
    if (!hard.contains(j)) {
      if (tr == 'slideleft' || tr == 'slideright' || tr == 'wipeleft' || tr == 'circleopen') {
        ev.add([t0 + td / 2 - 0.35, 'whoosh', 0.40]);
      } else if (tr == 'fadewhite') {
        ev.add([t0 + td / 2 - 0.1, 'impact', 0.50]);
      }
    }
    if (segs[j].role == 'climax' && segs[j - 1].role != 'climax') {
      ev.add([t0 - 2.0, 'riser', 0.35]);
      ev.add([t0, 'impact', 0.55]);
    }
    final sp = segs[j].fx['speed'] as Map<String, dynamic>?;
    if (sp != null && sp['mode'] == 'slowmo') ev.add([t0 + td / 2 - 0.35, 'whoosh', 0.40]);
  }
  ev.sort((a, b) => (a[0] as double).compareTo(b[0] as double));
  final out = <List<dynamic>>[];
  var last = -9.0;
  for (final e in ev) {
    final st = math.max(0.0, e[0] as double);
    if (st - last >= 0.8 && st < total - 0.3 && out.length < math.max(3, (total / 5).floor())) {
      out.add([st, e[1], e[2]]);
      last = st;
    }
  }
  return out;
}

Future<String> _synthSfx(String kind, String work, FxConfig cfg) async {
  final path = '$work/sfx_$kind.wav';
  if (File(path).existsSync()) return path;
  final s = (cfg.j['sfx'] as Map<String, dynamic>)[kind] as Map<String, dynamic>;
  await FF.run(['-f', 'lavfi', '-i', "aevalsrc='${s['expr']}':d=${s['dur']}:s=48000", '-af', s['post'] as String, '-ac', '2', '-ar', '48000', path]);
  return path;
}

/// Generative background music (free, no assets): mood ke hisaab se pad/pulse, FFmpeg aevalsrc se.
Future<String> makeMusic(String mood, double total, String work, FxConfig cfg) async {
  final m = cfg.j['music'] as Map<String, dynamic>;
  final ex = m['expr'] as Map<String, dynamic>;
  final expr = (ex[mood] ?? ex['cinematic']) as String;
  final path = '$work/music_$mood.wav';
  await FF.run(['-f', 'lavfi', '-i', "aevalsrc='$expr':d=${(total + 2).toStringAsFixed(1)}:s=44100", '-af', m['post'] as String, '-ac', '2', '-ar', '48000', path]);
  return path;
}

void _finalAudio(List<String> g, int? musicIdx, List<List<dynamic>> sfxIn, List<List<dynamic>> voIn, double total, String fade) {
  final nd = 1 + (musicIdx != null ? 1 : 0) + (sfxIn.isNotEmpty ? 1 : 0);
  g.add('[0:a]aformat=channel_layouts=stereo,aresample=48000,' +
      (nd > 1 ? 'asplit=$nd${List.generate(nd, (i) => '[d$i]').join()}' : 'anull[d0]'));
  final D = List.generate(nd, (i) => '[d$i]');
  var V = <String>[];
  if (voIn.isNotEmpty) {
    final nv = 1 + (musicIdx != null ? 1 : 0) + 1;
    final labels = <String>[];
    for (var k = 0; k < voIn.length; k++) {
      g.add('[${voIn[k][0]}:a]aformat=channel_layouts=stereo,aresample=48000,adelay=${((voIn[k][1] as double) * 1000).round()}:all=1[v$k]');
      labels.add('[v$k]');
    }
    g.add((labels.length > 1 ? '${labels.join()}amix=inputs=${labels.length}:normalize=0:duration=longest' : '${labels[0]}anull') +
        ',apad=whole_dur=${total.toStringAsFixed(3)},asplit=$nv${List.generate(nv, (i) => '[vv$i]').join()}');
    V = List.generate(nv, (i) => '[vv$i]');
  }
  final mix = <String>[];
  if (V.isNotEmpty) {
    g.add('${D.removeLast()}${V.removeLast()}sidechaincompress=threshold=0.02:ratio=8:attack=10:release=350[dfin]');
  } else {
    g.add('${D.removeLast()}anull[dfin]');
  }
  mix.add('[dfin]');
  if (musicIdx != null) {
    g.add('[$musicIdx:a]aformat=sample_rates=48000:channel_layouts=stereo,volume=${voIn.isNotEmpty ? 0.30 : 0.38}[m0]');
    g.add('[m0]${D.removeLast()}sidechaincompress=threshold=0.04:ratio=10:attack=20:release=400[m1]');
    var last = '[m1]';
    if (V.isNotEmpty) {
      g.add('[m1]${V.removeLast()}sidechaincompress=threshold=0.02:ratio=10:attack=10:release=400[m2]');
      last = '[m2]';
    }
    mix.add(last);
  }
  if (sfxIn.isNotEmpty) {
    final labels = <String>[];
    for (var k = 0; k < sfxIn.length; k++) {
      g.add('[${sfxIn[k][0]}:a]aformat=channel_layouts=stereo,aresample=48000,adelay=${((sfxIn[k][1] as double) * 1000).round()}:all=1,volume=${sfxIn[k][2]}[x$k]');
      labels.add('[x$k]');
    }
    g.add((labels.length > 1 ? '${labels.join()}amix=inputs=${labels.length}:normalize=0:duration=longest' : '${labels[0]}anull') +
        ',apad=whole_dur=${total.toStringAsFixed(3)}[sx0]');
    g.add('[sx0]${D.removeLast()}sidechaincompress=threshold=0.06:ratio=3:attack=10:release=200[sx1]');
    mix.add('[sx1]');
  }
  if (V.isNotEmpty) mix.add(V.removeLast());
  g.add('${mix.join()}amix=inputs=${mix.length}:duration=first:normalize=0[mix]');
  g.add('[mix]loudnorm=I=-14:TP=-1.5:LRA=11,$fade[a]');
}

/// Poori movie render (transitions, fx, grade, captions, music, SFX, VO) -> MP4 path.
Future<String> renderMovie({
  required List<Seg> segs,
  required String aspect,
  required bool hd,
  required String work,
  required String grade,
  required String mood,
  required FxConfig cfg,
  required String fontsDir,
  String? musicPath,
  List<VoLine> vo = const [],
  required void Function(double) onProgress,
}) async {
  final (W, H) = sizeFor(aspect, hd);
  final n = segs.length;
  final durs = [for (final s in segs) s.od];
  final trs = cfg.transitions;
  final tds = List<double>.filled(n, 0.0);
  final trans = List<String>.filled(n, '');
  for (var j = 1; j < n; j++) {
    final same = identical(segs[j].clip, segs[j - 1].clip);
    trans[j] = segs[j].transition.isNotEmpty ? segs[j].transition : (same ? 'fade' : trs[j % trs.length]);
    tds[j] = math.max(0.08, math.min(segs[j].td, math.min(0.45 * durs[j - 1], 0.45 * durs[j])));
  }
  final groups = _groups(n, tds);
  final steps = n + groups.length + 1;
  var done = 0;
  void tick([double frac = 0]) => onProgress(math.min(0.99, (done + frac) / steps));

  final prepped = <String>[];
  for (var i = 0; i < n; i++) {
    final out = '$work/seg${i.toString().padLeft(4, '0')}.mp4';
    await _prep(segs[i], W, H, grade, cfg, out);
    prepped.add(out);
    done++;
    tick();
  }

  final segStart = List<double>.filled(n, 0.0);
  final joined = <String>[];
  var base = 0.0, total = 0.0;
  for (var gi = 0; gi < groups.length; gi++) {
    final idx = groups[gi];
    final gt = [0.0, for (final j in idx.skip(1)) tds[j]];
    final gtr = ['', for (final j in idx.skip(1)) trans[j]];
    var L = durs[idx[0]];
    segStart[idx[0]] = base;
    for (var k = 1; k < idx.length; k++) {
      segStart[idx[k]] = base + L - gt[k];
      L += durs[idx[k]] - gt[k];
    }
    final out = '$work/grp${gi.toString().padLeft(3, '0')}.mp4';
    await _xfadeJoin([for (final j in idx) prepped[j]], [for (final j in idx) durs[j]], gt, gtr, out);
    joined.add(out);
    base += L;
    total += L;
    done++;
    tick();
  }

  String merged;
  if (joined.length == 1) {
    merged = joined[0];
  } else {
    final lst = '$work/list.txt';
    File(lst).writeAsStringSync(joined.map((p) => "file '$p'\n").join());
    merged = '$work/merged.mp4';
    await FF.run(['-f', 'concat', '-safe', '0', '-i', lst, '-c', 'copy', merged]);
  }

  // captions (word timestamps -> final timeline)
  final words = <CapWord>[];
  for (var i = 0; i < n; i++) {
    if (segs[i].fx['speed'] != null) continue;
    for (final w in segWords(segs[i].clip, segs[i].start, segs[i].end)) {
      words.add(CapWord(w.w, segStart[i] + w.s - segs[i].start, segStart[i] + w.e - segs[i].start, w.imp));
    }
  }
  words.sort((a, b) => a.s.compareTo(b.s));
  final ass = '$work/caps.ass';
  File(ass).writeAsStringSync(buildAss(words, W, H));

  // voiceover placement
  final first = <String, int>{};
  for (var i = 0; i < n; i++) {
    first.putIfAbsent(segs[i].sid, () => i);
  }
  final voPos = <List<dynamic>>[];
  var prevEnd = 0.0;
  final sortedVo = vo.where((v) => first.containsKey(v.sid)).toList()..sort((a, b) => first[a.sid]!.compareTo(first[b.sid]!));
  for (final v in sortedVo) {
    final st = math.max(segStart[first[v.sid]!] + 0.3, prevEnd + 0.25);
    if (st + v.dur <= total - 0.2) {
      voPos.add([v.path, st]);
      prevEnd = st + v.dur;
    }
  }

  final hard = {for (final grp in groups.skip(1)) grp[0]};
  final ev = _sfxEvents(segs, segStart, tds, trans, hard, total);

  final args = <String>['-i', merged];
  var nxt = 1;
  int? musicIdx;
  final mp = musicPath ?? await makeMusic(mood, total, work, cfg);
  args.addAll(['-stream_loop', '-1', '-i', mp]);
  musicIdx = nxt++;
  final sfxIn = <List<dynamic>>[];
  for (final e in ev) {
    args.addAll(['-i', await _synthSfx(e[1] as String, work, cfg)]);
    sfxIn.add([nxt++, e[0], e[2]]);
  }
  final voIn = <List<dynamic>>[];
  for (final v in voPos) {
    args.addAll(['-i', v[0] as String]);
    voIn.add([nxt++, v[1]]);
  }
  final g = <String>[];
  final fade = 'afade=t=out:st=${math.max(0.0, total - 1.5).toStringAsFixed(2)}:d=1.5';
  _finalAudio(g, musicIdx, sfxIn, voIn, total, fade);
  final finalPath = '$work/final.mp4';
  final tail = <String>[
    ...FF.venc('veryfast', '23', bitrate: hd ? '8M' : '5M'), '-pix_fmt', 'yuv420p',
    '-c:a', 'aac', '-b:a', '160k', '-movflags', '+faststart', '-t', total.toStringAsFixed(3), finalPath
  ];
  FF.onTime((sec) => onProgress(math.min(0.99, (done + math.min(1.0, sec / math.max(total, 0.1))) / steps)));
  List<String> build(String vfilter) => [...args, '-filter_complex', '$vfilter;${g.join(';')}', '-map', '[v]', '-map', '[a]', ...tail];
  try {
    await FF.run(build("[0:v]ass='$ass':fontsdir='$fontsDir'[v]"));
  } catch (e) {
    if (FF.cancelled) rethrow;
    await FF.run(build('[0:v]null[v]')); // libass na ho to bina captions movie phir bhi ban jati hai
  }
  return finalPath;
}

/// Thumbnail: best frame (face/sharp/emotion) + bold text via FFmpeg drawtext.
Future<void> makeThumbnail(List<Seg> segs, String aspect, String text, String fontFile, String work, String out) async {
  Clip? bc;
  var bt = 0.0, bs = -9.0;
  for (final sg in segs) {
    final tl = sg.clip.timeline;
    for (var s = sg.start.ceil(); s < sg.end.floor() && s < tl.length; s++) {
      final t = tl[s];
      final sc = 0.5 * math.min(t.face, 1.0) + 0.3 * t.sharp + 0.15 * t.smile + 0.2 * sg.intensity - 0.3 * math.min(t.motion * 8, 1.0);
      if (sc > bs) {
        bs = sc;
        bc = sg.clip;
        bt = s + 0.5;
      }
    }
  }
  if (bc == null) return;
  final (W, H) = aspect == '16:9' ? (1280, 720) : (1080, 1920);
  final words = text.trim().toUpperCase().split(RegExp(r'\s+')).where((x) => x.isNotEmpty).take(4).toList();
  final lines = <String>[];
  for (var i = 0; i < words.length; i += 2) {
    lines.add(words.skip(i).take(2).join(' '));
  }
  final tf = '$work/thumb_${aspect.replaceAll(':', 'x')}.txt';
  File(tf).writeAsStringSync(lines.join('\n'));
  final left = bc.faceCx > 0.5;
  final fs = aspect == '16:9' ? 110 : 130;
  final x = left ? 'w*0.05' : 'w-text_w-w*0.05';
  await FF.run([
    '-ss', bt.toStringAsFixed(2), '-i', bc.path, '-frames:v', '1',
    '-vf',
    'scale=$W:$H:force_original_aspect_ratio=increase,crop=$W:$H,eq=contrast=1.15:saturation=1.25,'
        'drawtext=fontfile=$fontFile:textfile=$tf:fontsize=$fs:fontcolor=0xFFD600:borderw=9:bordercolor=black:x=$x:y=h-text_h-60',
    '-q:v', '3', out
  ]);
}
