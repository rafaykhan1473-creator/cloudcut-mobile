import 'package:google_mlkit_face_detection/google_mlkit_face_detection.dart';

class FaceResult {
  final bool has;
  final double cx, smile;
  FaceResult(this.has, this.cx, this.smile);
}

/// ML Kit: free, on-device (koi API key nahi).
class FaceService {
  final FaceDetector _d = FaceDetector(
      options: FaceDetectorOptions(enableClassification: true, performanceMode: FaceDetectorMode.fast));
  bool failed = false;

  Future<FaceResult> detect(String path, double imgW) async {
    if (failed) return FaceResult(false, 0, 0);
    try {
      final faces = List<Face>.of(await _d.processImage(InputImage.fromFilePath(path)));
      if (faces.isEmpty) return FaceResult(false, 0, 0);
      faces.sort((a, b) => (b.boundingBox.width * b.boundingBox.height).compareTo(a.boundingBox.width * a.boundingBox.height));
      final f = faces.first;
      return FaceResult(true, f.boundingBox.center.dx / imgW, f.smilingProbability ?? 0.0);
    } catch (_) {
      failed = true;
      return FaceResult(false, 0, 0);
    }
  }

  Future<void> close() async {
    try {
      await _d.close();
    } catch (_) {}
  }
}
