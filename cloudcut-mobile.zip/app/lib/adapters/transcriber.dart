import 'package:whisper_flutter_new/whisper_flutter_new.dart';
import '../models.dart';

class TrResult {
  final List<Word> words;
  final List<Sentence> sentences;
  TrResult(this.words, this.sentences);
}

/// Open-source Whisper (whisper.cpp) - poori tarah on-device. Model pehli dafa ek baar download hota hai.
class Transcriber {
  Whisper? _w;
  bool failed = false;

  Future<TrResult?> run(String wavPath) async {
    if (failed) return null;
    try {
      _w ??= Whisper(model: WhisperModel.tiny);
      final dynamic r = await _w!.transcribe(
        transcribeRequest: TranscribeRequest(audio: wavPath, isTranslate: false, isNoTimestamps: false, splitWords: false),
      );
      final dynamic segs = r.segments;
      final words = <Word>[];
      final sents = <Sentence>[];
      double secs(dynamic v) {
        if (v is Duration) return v.inMilliseconds / 1000.0;
        if (v is num) return v.toDouble();
        return 0.0;
      }

      for (final dynamic sg in (segs as List)) {
        final s = secs(sg.fromTs), e = secs(sg.toTs);
        final text = ('${sg.text}').trim();
        if (text.isEmpty || e <= s || RegExp(r'^[\[\(].*[\]\)]$').hasMatch(text)) continue;
        sents.add(Sentence(s, e, text));
        final toks = text.split(RegExp(r'\s+')).where((x) => x.isNotEmpty).toList();
        final total = toks.fold<int>(0, (a, b) => a + b.length + 1);
        var t = s;
        for (final tok in toks) {
          final d = (e - s) * (tok.length + 1) / total; // segment time ko words mein baanta
          words.add(Word(tok, t, t + d * 0.9));
          t += d;
        }
      }
      return TrResult(words, sents);
    } catch (_) {
      failed = true; // captions skip ho jayenge, baaki movie banti rahegi
      return null;
    }
  }
}
