import 'dart:io';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path_provider/path_provider.dart';

/// Android ka built-in offline TTS (Urdu/Hindi bhi agar phone mein voice installed ho).
class Narrator {
  final FlutterTts _t = FlutterTts();

  Future<String?> synth(String text, String lang, String name) async {
    try {
      await _t.setLanguage(lang);
      await _t.awaitSynthCompletion(true);
      await (_t as dynamic).synthesizeToFile(text, name);
      final dir = await getExternalStorageDirectory();
      if (dir == null) return null;
      final f = File('${dir.path}/$name');
      return f.existsSync() && f.lengthSync() > 1000 ? f.path : null;
    } catch (_) {
      return null;
    }
  }
}
