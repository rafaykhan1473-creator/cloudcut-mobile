import 'adapters/faces.dart';
import 'adapters/narrator.dart';
import 'adapters/transcriber.dart';

export 'adapters/faces.dart' show FaceResult, FaceService;
export 'adapters/narrator.dart' show Narrator;
export 'adapters/transcriber.dart' show TrResult, Transcriber;

/// Plugin-free glue. Plugin code sirf lib/adapters/ mein hai (CI fallback inhe stubs se badal sakta hai).
class Services {
  Transcriber? transcriber = Transcriber();
  FaceService? faces;
  Narrator narrator = Narrator();
  Services() {
    try {
      faces = FaceService();
    } catch (_) {}
  }
}
