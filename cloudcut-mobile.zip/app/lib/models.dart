class Word {
  String w;
  double s, e;
  bool imp;
  Word(this.w, this.s, this.e, [this.imp = false]);
}

class Sentence {
  double s, e;
  String text;
  bool important;
  Sentence(this.s, this.e, this.text, [this.important = false]);
}

class SecStat {
  double face = 0, smile = 0, motion = 0, sharp = 0, luma = 0.5, ei = 0, rms = 0;
}

class HashPt {
  final double t;
  final String h;
  HashPt(this.t, this.h);
}

class Clip {
  final String path;
  final String name;
  final int position;
  Clip(this.path, this.name, this.position);
  double duration = 0;
  int width = 0, height = 0;
  bool hasAudio = false;
  DateTime? creationTime;
  List<List<double>> silences = [];
  List<Word> words = [];
  List<Sentence> sentences = [];
  List<SecStat> timeline = [];
  List<HashPt> hashes = [];
  double faceCx = -1, faceRatio = 0, smileRatio = 0, motion = 0, sharp = 0, luma = 0.45, quality = 0.7, gainDb = 0;
  String emotion = 'neutral';
  double intensity = 0.3;
  String action = 'low';
}

class Seg {
  String sid = '';
  final Clip clip;
  double start, end;
  double score = 0;
  bool important = false;
  String text = '';
  List<String> hashes = [];
  String emotion = 'neutral';
  double intensity = 0.3;
  String role = '';
  String transition = 'fade';
  double td = 0.4;
  bool isHook = false;
  Map<String, dynamic> fx = {};
  double? outDur;
  Seg(this.clip, this.start, this.end);
  double get dur => end - start;
  double get od => outDur ?? (end - start);
  Seg copy() {
    final s = Seg(clip, start, end);
    s.sid = sid;
    s.score = score;
    s.important = important;
    s.text = text;
    s.hashes = hashes;
    s.emotion = emotion;
    s.intensity = intensity;
    s.role = role;
    s.transition = transition;
    s.td = td;
    s.isHook = isHook;
    s.fx = Map<String, dynamic>.from(fx);
    s.outDur = outDur;
    return s;
  }
}

class Meta {
  String title = '', description = '', thumbText = '', shortsTitle = '';
  List<String> hashtags = [], shortsHashtags = [];
  Map<String, dynamic> toJson() => {
        'title': title,
        'description': description,
        'hashtags': hashtags,
        'thumbText': thumbText,
        'shortsTitle': shortsTitle,
        'shortsHashtags': shortsHashtags,
      };
}

class Options {
  bool movie169 = true;
  bool shorts = true;
  bool hd = false; // false = 720p (fast), true = 1080p
  String? musicPath; // optional: user ka apna royalty-free music
  String brief = '';
  bool narration = false;
  String lang = 'en-US';
}

class Prog {
  final double value; // 0..1
  final String msg;
  const Prog(this.value, this.msg);
}
