import 'dart:convert';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit_config.dart';
import 'package:ffmpeg_kit_flutter_new/ffprobe_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';

/// Thin wrapper: har FFmpeg command yahin se guzarti hai (free, on-device).
class FF {
  static bool cancelled = false;
  static String vcodec = 'libx264';

  /// FFmpegKit ke variant mein libx264 na ho to phone ka hardware H.264 encoder (MediaCodec) use hota hai.
  static Future<void> detectEncoder() async {
    try {
      await run(['-f', 'lavfi', '-i', 'color=c=black:s=64x64:d=0.2', '-c:v', 'libx264', '-f', 'null', '-']);
      vcodec = 'libx264';
    } catch (_) {
      vcodec = 'h264_mediacodec';
    }
  }

  static List<String> venc(String preset, String crf, {String bitrate = '6M'}) =>
      vcodec == 'libx264' ? ['-c:v', 'libx264', '-preset', preset, '-crf', crf] : ['-c:v', 'h264_mediacodec', '-b:v', bitrate];

  static Future<void> run(List<String> args) async {
    if (cancelled) throw Exception('cancelled');
    final session = await FFmpegKit.executeWithArguments(['-y', '-hide_banner', ...args]);
    final rc = await session.getReturnCode();
    if (!ReturnCode.isSuccess(rc)) {
      if (cancelled) throw Exception('cancelled');
      final logs = (await session.getAllLogsAsString()) ?? '';
      throw Exception('ffmpeg failed: ${logs.length > 900 ? logs.substring(logs.length - 900) : logs}');
    }
  }

  static Future<Map<String, dynamic>> probe(String path) async {
    final s = await FFprobeKit.executeWithArguments(
        ['-v', 'error', '-print_format', 'json', '-show_streams', '-show_format', path]);
    final out = (await s.getOutput()) ?? '{}';
    return jsonDecode(out) as Map<String, dynamic>;
  }

  static Future<void> setFonts(String dir) async {
    try {
      await FFmpegKitConfig.setFontDirectory(dir);
    } catch (_) {}
  }

  static void onTime(void Function(double seconds)? cb) {
    try {
      FFmpegKitConfig.enableStatisticsCallback((stat) {
        if (cb != null) cb(stat.getTime() / 1000.0);
      });
    } catch (_) {}
  }

  static Future<void> cancel() async {
    cancelled = true;
    try {
      await FFmpegKit.cancel();
    } catch (_) {}
  }
}
