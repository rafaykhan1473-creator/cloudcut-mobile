# CloudCut Mobile — free, offline AI movie editor (sirf phone se)

Select videos → **Create Movie** → AI khud edit karta hai (hook, story, cuts, captions, music, SFX, transitions, effects, grade) →
16:9 movie + 9:16 Shorts + thumbnail + title/description/hashtags → **Save** to Gallery. Koi server, API key, laptop nahi.

## APK banane ka tareeqa (sirf Android phone + browser)
1. github.com par free account banayein → **New repository** → *Public* → Create.
2. Repo mein **Add file → Upload files** → `cloudcut-mobile.zip` (jo Claude ne diya) select karein → Commit.
3. **Add file → Create new file** → naam likhein `.github/workflows/build-apk.yml` → chat mein diya gaya YAML paste karein → Commit.
4. **Actions** tab → *Build CloudCut APK* → **Run workflow**. 10-20 minute intezar.
5. **Releases** (right side) → *CloudCut APK (latest)* → `app-arm64-v8a-release.apk` download → install
   (Settings mein "Install unknown apps" allow karein).
Build self-healing hai (`tool/ci_build.sh`): pehle FULL build; fail ho to speech/face/TTS plugins stub se badal kar CORE APK banata hai.
Run page ke *Summary* mein error ka aakhri hissa dikhta hai, aur `ci-diagnostics` artifact mein `analyze.log`, `build_*.log`,
`plugin_api.txt` (download hue asli plugin source ki API signatures) hote hain. Inhe Claude ko bhej dein — fix zip mein aayega;
GitHub repo mein purani zip ko nayi se replace karke Run workflow dobara dabayein (workflow YAML kabhi badalna nahi padta).

## Free stack (on-device)
FFmpegKit (community fork) · whisper.cpp (speech, model pehli baar download ~75MB) · ML Kit face/smile (free, on-device) ·
Dart math for blur/motion/loudness · generative music + FFmpeg-synthesized SFX (koi asset ya license nahi) · Android TTS (narration).

## Honest limits
- Compatibility fallbacks: x264 na ho to phone ka MediaCodec H.264 encoder; libass na ho to movie bina captions; ML Kit/Whisper fail ho to faces/captions skip (movie phir bhi banti hai).
- Phone par render slow hai: 720p default; 1080p optional; 4K nahi. 120 clips ke liye 30-90+ minute lag sakte hain. App khula rakhein.
- Emotion: smile (ML Kit) + audio/motion se; sad/fear/surprise reliable detect nahi hote (heuristic).
- Story order = shooting time / filename number / picker order. Semantic understanding (LLM) on-device nahi.
- Music generative pads hain (professional library jaisa nahi) — apna royalty-free track "More options" se de sakte hain.
- Slow-motion frame-duplication (smooth nahi). Narration = aapki brief ki lines, device TTS se.
- Yeh code yahan compile/run nahi hua (sandbox mein Flutter nahi). FFmpeg graphs yahan asli FFmpeg par test hue hain; Dart/plugins
  (ffmpeg_kit_flutter_new, whisper_flutter_new API) CI mein pehli baar compile honge.
