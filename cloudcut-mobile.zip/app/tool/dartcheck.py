"""Mini Dart lexer: strings/interpolation/comments samajh kar bracket balance check. (Flutter compiler ka replacement nahi.)"""
import sys, pathlib
P = {'(': ')', '[': ']', '{': '}'}

class Err(Exception): pass

def line(s, i): return s.count('\n', 0, i) + 1

def skip_string(s, i):
    raw = i > 0 and s[i-1] == 'r'
    q = s[i]; triple = s.startswith(q*3, i); d = q*3 if triple else q
    start = i; i += len(d)
    while i < len(s):
        if s[i] == '\\' and not raw: i += 2; continue
        if s.startswith(d, i): return i + len(d)
        if s[i] == '$' and not raw and i+1 < len(s) and s[i+1] == '{':
            i = scan(s, i+2, True) + 1; continue
        if s[i] == '\n' and not triple: raise Err(f"unterminated string line {line(s,start)}")
        i += 1
    raise Err(f"unterminated string line {line(s,start)}")

def scan(s, i, interp=False):
    st = []
    while i < len(s):
        c = s[i]
        if s.startswith('//', i):
            j = s.find('\n', i); i = len(s) if j < 0 else j; continue
        if s.startswith('/*', i):
            j = s.find('*/', i); i = len(s) if j < 0 else j + 2; continue
        if c in '\'"':
            i = skip_string(s, i); continue
        if c in P: st.append((c, i))
        elif c in ')]}':
            if interp and c == '}' and not st: return i
            if not st: raise Err(f"unexpected {c} line {line(s,i)}")
            o, oi = st.pop()
            if P[o] != c: raise Err(f"mismatch {o}(line {line(s,oi)}) vs {c}(line {line(s,i)})")
        i += 1
    if interp: raise Err("unterminated interpolation")
    if st: raise Err(f"unclosed {st[-1][0]} line {line(s, st[-1][1])}")
    return i

bad = 0
for f in sorted(pathlib.Path(sys.argv[1]).rglob('*.dart')):
    try:
        scan(f.read_text(), 0); print("OK  ", f)
    except Err as e:
        bad += 1; print("FAIL", f, e)
sys.exit(1 if bad else 0)
