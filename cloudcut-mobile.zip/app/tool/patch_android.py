"""flutter create ke baad generated Android project ko CloudCut ke liye patch karta hai (permissions, minSdk, label)."""
import pathlib, re, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
mf = root / "android/app/src/main/AndroidManifest.xml"
s = mf.read_text()
extra = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>
    <queries>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
    </queries>
"""
if "android.permission.WAKE_LOCK" not in s:
    s = s.replace("<application", extra + "    <application", 1)
if "largeHeap" not in s:
    s = s.replace("<application", '<application android:largeHeap="true"', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="CloudCut"', s, count=1)
mf.write_text(s)

for name, repl in (("build.gradle.kts", "minSdk = 24"), ("build.gradle", "minSdkVersion 24")):
    p = root / "android/app" / name
    if p.exists():
        t = p.read_text()
        t2 = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", repl, t)
        p.write_text(t2)
        print(f"{name}: minSdk patched" if t != t2 else f"{name}: minSdk pattern not found (check manually)")
print("manifest patched")
