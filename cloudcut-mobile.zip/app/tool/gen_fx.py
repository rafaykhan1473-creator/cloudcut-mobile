"""assets/fx.json banata hai (grades, SFX, generative music) - backend render.py/sfx.py se same strings, taake phone aur server ek jaisa dikhe."""
import json, sys, types
sys.path.insert(0, '/home/claude/cloudcut/backend')
cfg = types.ModuleType("botocore.config"); cfg.Config = lambda **k: None
bc = types.ModuleType("botocore"); bc.config = cfg
ps = types.ModuleType("pydantic_settings"); ps.BaseSettings = type("B", (), {})
sys.modules.update({"botocore": bc, "botocore.config": cfg, "boto3": types.ModuleType("boto3"), "pydantic_settings": ps})
from app.pipeline import render, sfx

music = {
 "cinematic": "(0.16*sin(2*PI*110*t)+0.11*sin(2*PI*164.81*t)+0.09*sin(2*PI*220*t)+0.07*sin(2*PI*261.63*t))*(0.75+0.25*sin(2*PI*0.1*t))",
 "happy": "(0.14*sin(2*PI*261.63*t)+0.11*sin(2*PI*329.63*t)+0.09*sin(2*PI*392*t)+0.07*sin(2*PI*523.25*t))*(0.8+0.2*sin(2*PI*2*t))",
 "sad": "(0.18*sin(2*PI*110*t)+0.12*sin(2*PI*130.81*t)+0.1*sin(2*PI*164.81*t)+0.07*sin(2*PI*220*t))*(0.7+0.3*sin(2*PI*0.07*t))",
 "fear": "(0.2*sin(2*PI*55*t)+0.14*sin(2*PI*58.27*t)+0.08*sin(2*PI*82.41*t))*(0.8+0.2*sin(2*PI*6*t))",
 "excitement": "sin(2*PI*50*t)*exp(-12*mod(t,0.5))*0.7+(0.1*sin(2*PI*196*t)+0.08*sin(2*PI*246.94*t)+0.06*sin(2*PI*293.66*t))*(0.6+0.4*abs(sin(PI*t*2)))",
}
music["surprise"] = music["neutral"] = music["cinematic"]
fx = {"grades": render.GRADES, "transitions": render.TRANSITIONS,
      "sfx": {k: {"expr": v[0], "dur": v[1], "post": v[2]} for k, v in sfx.SYN.items()},
      "music": {"expr": music, "post": "lowpass=f=2200,aecho=0.8:0.7:500:0.35"}}
json.dump(fx, open("assets/fx.json", "w"), indent=1)
print("fx.json written")
