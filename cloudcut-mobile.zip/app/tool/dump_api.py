"""Download hue ASLI plugin source se public API signatures nikalta hai (docs ka bharosa nahi, source ka)."""
import json, pathlib, re, sys

WATCH = ["ffmpeg_kit_flutter_new", "whisper_flutter_new", "google_mlkit_face_detection", "flutter_tts",
         "gal", "share_plus", "open_filex", "wakelock_plus", "file_picker"]
app = pathlib.Path(sys.argv[1])
cfg = json.loads((app / ".dart_tool/package_config.json").read_text())
sig = re.compile(r"^\s*(static\s+)?(Future<[^>]*>|Future|Stream<[^>]*>|void|bool|int|double|String|[A-Z]\w*)\??\s+\w+\s*\(|^\s*(abstract\s+|final\s+)?class\s+\w+|^\s*factory\s+\w+|^\s*const\s+\w+\(")
for p in cfg["packages"]:
    if p["name"] not in WATCH:
        continue
    root = (app / ".dart_tool" / p["rootUri"]).resolve() if not p["rootUri"].startswith("file:") else pathlib.Path(p["rootUri"][7:])
    print(f"\n===== {p['name']}  ({root.name}) =====")
    n = 0
    for f in sorted((root / "lib").rglob("*.dart")):
        for i, line in enumerate(f.read_text(errors="ignore").splitlines(), 1):
            if sig.match(line) and not line.strip().startswith("//"):
                print(f"{f.relative_to(root)}:{i}: {line.strip()[:140]}")
                n += 1
                if n > 350:
                    break
        if n > 350:
            print("... (truncated)")
            break
