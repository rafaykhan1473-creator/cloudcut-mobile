"""Optional plugins ko hata kar stubs lagata hai (CI fallback). Usage: degrade.py <app_dir> whisper faces tts"""
import pathlib, re, shutil, sys

MAP = {  # name: (adapter file, stub file, pubspec dependency)
    "whisper": ("transcriber.dart", "transcriber.dart", "whisper_flutter_new"),
    "faces": ("faces.dart", "faces.dart", "google_mlkit_face_detection"),
    "tts": ("narrator.dart", "narrator.dart", "flutter_tts"),
}
app = pathlib.Path(sys.argv[1])
pub = app / "pubspec.yaml"
txt = pub.read_text()
for name in sys.argv[2:]:
    adapter, stub, dep = MAP[name]
    shutil.copy(app / "tool/stubs" / stub, app / "lib/adapters" / adapter)
    txt = re.sub(rf"^\s+{dep}:.*\n", "", txt, flags=re.M)
    print(f"degraded: {name} (-{dep})")
pub.write_text(txt)
