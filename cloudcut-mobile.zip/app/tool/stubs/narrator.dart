/// STUB (TTS plugin unavailable in this build): narration skip.
class Narrator {
  Future<String?> synth(String text, String lang, String name) async => null;
}
