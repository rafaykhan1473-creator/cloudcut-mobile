import '../models.dart';

class TrResult {
  final List<Word> words;
  final List<Sentence> sentences;
  TrResult(this.words, this.sentences);
}

/// STUB (speech plugin unavailable in this build): captions skip, baaki movie banti hai.
class Transcriber {
  bool failed = true;
  Future<TrResult?> run(String wavPath) async => null;
}
