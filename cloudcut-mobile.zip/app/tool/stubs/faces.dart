class FaceResult {
  final bool has;
  final double cx, smile;
  FaceResult(this.has, this.cx, this.smile);
}

/// STUB (face plugin unavailable in this build): center crop + no smile data.
class FaceService {
  bool failed = true;
  Future<FaceResult> detect(String path, double imgW) async => FaceResult(false, 0, 0);
  Future<void> close() async {}
}
