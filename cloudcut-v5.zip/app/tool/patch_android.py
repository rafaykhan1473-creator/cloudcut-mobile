"""flutter create ke baad generated Android project ko CloudCut ke liye patch karta hai (permissions, minSdk, label)."""
import pathlib, re, sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
mf = root / "android/app/src/main/AndroidManifest.xml"
s = mf.read_text()
extra = """    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>
    <queries>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
    </queries>
"""
if "android.permission.WAKE_LOCK" not in s:
    s = s.replace("<application", extra + "    <application", 1)
if "largeHeap" not in s:
    s = s.replace("<application", '<application android:largeHeap="true"', 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="CloudCut"', s, count=1)
mf.write_text(s)

for name, repl in (("build.gradle.kts", "minSdk = 24"), ("build.gradle", "minSdkVersion 24")):
    p = root / "android/app" / name
    if p.exists():
        t = p.read_text()
        t2 = re.sub(r"minSdk(Version)?\s*=?\s*flutter\.minSdkVersion", repl, t)
        p.write_text(t2)
        print(f"{name}: minSdk patched" if t != t2 else f"{name}: minSdk pattern not found (check manually)")
print("manifest patched")


# ---- compileSdk override for ALL plugins (file_picker waghera purane compileSdk par bane hote hain) ----
SDK = int(sys.argv[2]) if len(sys.argv) > 2 else 36
BEGIN, END = "// CLOUDCUT-COMPILESDK-BEGIN", "// CLOUDCUT-COMPILESDK-END"
KTS = f"""{BEGIN}
subprojects {{
    afterEvaluate {{
        val androidExt = extensions.findByName("android")
        if (androidExt != null) {{
            var done = false
            for (m in listOf("setCompileSdkVersion" to Integer.TYPE, "setCompileSdk" to Integer::class.java)) {{
                if (!done) {{
                    try {{
                        androidExt.javaClass.getMethod(m.first, m.second).invoke(androidExt, {SDK})
                        done = true
                    }} catch (e: Exception) {{
                    }}
                }}
            }}
        }}
    }}
}}
{END}
"""
GROOVY = f"""{BEGIN}
subprojects {{
    afterEvaluate {{ p ->
        if (p.hasProperty('android')) {{
            try {{ p.android.compileSdkVersion {SDK} }} catch (Throwable t) {{ }}
        }}
    }}
}}
{END}
"""
for name, block in (("build.gradle.kts", KTS), ("build.gradle", GROOVY)):
    rp = root / "android" / name
    if not rp.exists():
        continue
    t = rp.read_text()
    t = re.sub(re.escape(BEGIN) + r".*?" + re.escape(END) + r"\n?", "", t, flags=re.S)  # purana block hatao (idempotent)
    m = re.search(r"^subprojects\s*\{", t, flags=re.M)
    t = (t[:m.start()] + block + "\n" + t[m.start():]) if m else (t + "\n" + block)
    rp.write_text(t)
    print(f"{name}: compileSdk override = {SDK}")
gp = root / "android/gradle.properties"
if gp.exists():
    g = re.sub(r"^android\.suppressUnsupportedCompileSdk=.*\n?", "", gp.read_text(), flags=re.M).rstrip("\n")
    gp.write_text(g + f"\nandroid.suppressUnsupportedCompileSdk={SDK}\n")
