#!/usr/bin/env bash
# CloudCut CI build with self-healing: pub get -> API dump -> analyze -> FULL build -> (auto) CORE fallback.
# Saara logic yahin hai, taake phone se sirf zip replace karna pade (workflow YAML kabhi badalna nahi).
set -uo pipefail
APP="$(cd "${1:?usage: ci_build.sh <app_dir>}" && pwd)"   # hamesha absolute path (cd ke baad relative path toot jata tha)
OUT="$APP/ci-out"; mkdir -p "$OUT"
SUMMARY="${GITHUB_STEP_SUMMARY:-/dev/null}"
fail() { { echo "## ❌ $1"; echo '```'; tail -n 45 "$2" 2>/dev/null; echo '```'; } >> "$SUMMARY"; echo "FAILED: $1"; exit 1; }

flutter create --platforms=android --org com.cloudcut --project-name cloudcut_mobile /tmp/shell > "$OUT/create.log" 2>&1 || fail "flutter create" "$OUT/create.log"
rm -rf "$APP/android"; cp -r /tmp/shell/android "$APP/android"
python3 "$APP/tool/patch_android.py" "$APP" | tee "$OUT/patch.log"
cd "$APP"

# 1) dependencies - agar optional plugin resolve na ho to auto-replace (stub)
if ! flutter pub get > "$OUT/pub_get.log" 2>&1; then
  echo "pub get failed -> optional plugins hata kar dobara"
  python3 tool/degrade.py . whisper faces tts
  flutter pub get > "$OUT/pub_get_core.log" 2>&1 || fail "flutter pub get (core deps)" "$OUT/pub_get_core.log"
fi
flutter pub deps --no-dev > "$OUT/deps.txt" 2>&1 || true
python3 tool/dump_api.py . > "$OUT/plugin_api.txt" 2>&1 || true   # asli plugin source ki signatures

# 2) static analysis (errors yahin sabse saaf dikhte hain)
flutter analyze --no-pub > "$OUT/analyze.log" 2>&1 || true
grep -c "error •" "$OUT/analyze.log" | sed 's/^/analyzer errors: /'

build() {  # $1 = label
  flutter build apk --release --split-per-abi > "$OUT/build_$1.log" 2>&1
  local rc=$?
  [ $rc -eq 0 ] && for f in build/app/outputs/flutter-apk/app-*-release.apk; do
    mv "$f" "build/app/outputs/flutter-apk/CloudCut-$1-$(basename "$f" | sed 's/^app-//')"
  done
  return $rc
}

# file_picker jaise plugins "compile against version N or later" error dein to N padh kar override badha ke ek dafa retry
retry_sdk() {  # $1 = log file
  local n; n=$(grep -oE "compile against version [0-9]+ or later" "$1" | grep -oE "[0-9]+" | sort -n | tail -1)
  if [ -n "${n:-}" ]; then echo "plugins need compileSdk >= $n -> override retry"; python3 tool/patch_android.py . "$n" | tail -2; return 0; fi
  return 1
}
if build FULL || { retry_sdk "$OUT/build_FULL.log" && cp "$OUT/build_FULL.log" "$OUT/build_FULL_attempt1.log" && build FULL; }; then
  echo FULL > "$OUT/variant"; echo "## ✅ FULL APK built (speech + faces + narration)" >> "$SUMMARY"
else
  echo "FULL build failed -> CORE fallback (whisper/mlkit/tts plugins removed)"
  python3 tool/degrade.py . whisper faces tts
  flutter pub get > "$OUT/pub_get_core.log" 2>&1
  if build CORE || { retry_sdk "$OUT/build_CORE.log" && build CORE; }; then
    echo CORE > "$OUT/variant"
    { echo "## ⚠️ CORE APK built (FULL failed). Captions/face-crop/narration plugins disabled."; echo "FULL error (tail):"; echo '```'; tail -n 30 "$OUT/build_FULL.log"; echo '```'; } >> "$SUMMARY"
  else
    echo FAILED > "$OUT/variant"
    fail "FULL and CORE builds both failed" "$OUT/build_CORE.log"
  fi
fi
ls -la build/app/outputs/flutter-apk/ | tee "$OUT/apks.txt"
