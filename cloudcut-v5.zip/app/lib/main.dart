import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:open_filex/open_filex.dart';
import 'package:share_plus/share_plus.dart';
import 'models.dart';
import 'pipeline.dart';

void main() => runApp(const CloudCutApp());

class CloudCutApp extends StatelessWidget {
  const CloudCutApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'CloudCut',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFFFF5A36), brightness: Brightness.dark, useMaterial3: true),
        home: const HomeScreen(),
      );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final name = TextEditingController(text: 'My Movie');
  final brief = TextEditingController();
  List<PlatformFile> files = [];
  final o = Options();
  String? musicName;

  Future<void> pick() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.video, allowMultiple: true);
    if (r == null) return;
    setState(() => files = r.files.where((f) => f.path != null).take(120).toList());
  }

  Future<void> pickMusic() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.audio);
    if (r == null || r.files.single.path == null) return;
    setState(() {
      o.musicPath = r.files.single.path;
      musicName = r.files.single.name;
    });
  }

  void create() {
    if (files.isEmpty) return;
    if (!o.movie169 && !o.shorts) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Movie ya Shorts mein se ek select karein')));
      return;
    }
    o.brief = brief.text;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ProcessScreen(
          paths: files.map((f) => f.path!).toList(),
          names: files.map((f) => f.name).toList(),
          projectName: name.text.trim().isEmpty ? 'My Movie' : name.text.trim(),
          options: o,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('CloudCut'), actions: [
          IconButton(
            icon: const Icon(Icons.video_library),
            tooltip: 'My movies',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LibraryScreen())),
          )
        ]),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('1. Videos select karein', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: pick,
            icon: const Icon(Icons.add_to_photos),
            label: Text(files.isEmpty ? 'Select videos (1-120)' : '${files.length} videos selected - change'),
          ),
          const SizedBox(height: 16),
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Movie name', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('YouTube movie (16:9)'),
              value: o.movie169,
              onChanged: (v) => setState(() => o.movie169 = v)),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Shorts (9:16)'),
              value: o.shorts,
              onChanged: (v) => setState(() => o.shorts = v)),
          SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('HD 1080p (slower)'),
              subtitle: const Text('Off = 720p, phone par tez'),
              value: o.hd,
              onChanged: (v) => setState(() => o.hd = v)),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: o.pacing,
            decoration: const InputDecoration(labelText: 'Editing style', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'full', child: Text('Full clips (poori shots rakho)')),
              DropdownMenuItem(value: 'cinematic', child: Text('Cinematic (chhote, tez cuts)')),
            ],
            onChanged: (v) => setState(() => o.pacing = v ?? 'full'),
          ),
          const SizedBox(height: 8),
          ExpansionTile(
            title: const Text('More options (optional)'),
            childrenPadding: const EdgeInsets.symmetric(horizontal: 4),
            children: [
              TextField(
                  controller: brief,
                  maxLines: 3,
                  maxLength: 500,
                  decoration: const InputDecoration(
                      labelText: 'Story brief (1-2 lines)', helperText: 'Title/description + narration ke liye', border: OutlineInputBorder())),
              SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('AI narration (only if needed)'),
                  value: o.narration,
                  onChanged: (v) => setState(() => o.narration = v)),
              DropdownButtonFormField<String>(
                value: o.lang,
                decoration: const InputDecoration(labelText: 'Narration language', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'en-US', child: Text('English')),
                  DropdownMenuItem(value: 'ur-PK', child: Text('Urdu')),
                  DropdownMenuItem(value: 'hi-IN', child: Text('Hindi')),
                ],
                onChanged: (v) => setState(() => o.lang = v ?? 'en-US'),
              ),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                  onPressed: pickMusic,
                  icon: const Icon(Icons.music_note),
                  label: Text(musicName ?? 'Use my own royalty-free music (default: auto music)')),
              const SizedBox(height: 8),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            height: 60,
            child: FilledButton.icon(
              onPressed: files.isEmpty ? null : create,
              icon: const Icon(Icons.movie_creation, size: 28),
              label: const Text('Create Movie', style: TextStyle(fontSize: 20)),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'AI poori editing khud karega: hook, story, captions, music, SFX, effects, colour grade, thumbnail, title & hashtags. '
            'Sab kuch aapke phone par - internet ki zaroorat nahi (sirf pehli baar speech model download hota hai).',
            style: TextStyle(color: Colors.grey),
          ),
        ]),
      );
}

class ProcessScreen extends StatefulWidget {
  final List<String> paths, names;
  final String projectName;
  final Options options;
  const ProcessScreen({super.key, required this.paths, required this.names, required this.projectName, required this.options});
  @override
  State<ProcessScreen> createState() => _ProcessScreenState();
}

class _ProcessScreenState extends State<ProcessScreen> {
  final p = Pipeline();
  String? error;
  bool done = false;

  @override
  void initState() {
    super.initState();
    p.run(widget.paths, widget.names, widget.projectName, widget.options).then((_) {
      if (!mounted) return;
      setState(() => done = true);
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const LibraryScreen()));
    }).catchError((e) {
      if (mounted) setState(() => error = '$e'.contains('cancelled') ? 'Cancelled' : '$e');
    });
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: error != null || done,
        child: Scaffold(
          appBar: AppBar(title: const Text('Creating your movie')),
          body: Padding(
            padding: const EdgeInsets.all(24),
            child: error != null
                ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.error_outline, size: 56, color: Colors.redAccent),
                    const SizedBox(height: 12),
                    SelectableText(error!, textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(onPressed: () => Navigator.pop(context), child: const Text('Back')),
                  ])
                : ValueListenableBuilder<Prog>(
                    valueListenable: p.prog,
                    builder: (_, v, __) => Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('${(v.value * 100).round()}%', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      LinearProgressIndicator(value: v.value, minHeight: 10),
                      const SizedBox(height: 16),
                      Text(v.msg, textAlign: TextAlign.center),
                      const SizedBox(height: 24),
                      const Text('App khula rakhein - screen on rahegi.\nBade projects mein kuch minute lagte hain.',
                          textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                      const SizedBox(height: 24),
                      OutlinedButton(onPressed: p.cancel, child: const Text('Cancel')),
                    ]),
                  ),
          ),
        ),
      );
}

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});
  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  List<File> movies = [];

  Future<void> load() async {
    final d = await moviesDir();
    final l = d.listSync().whereType<File>().where((f) => f.path.endsWith('.mp4')).toList()
      ..sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    if (mounted) setState(() => movies = l);
  }

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> save(File f) async {
    try {
      if (!await Gal.hasAccess()) await Gal.requestAccess();
      await Gal.putVideo(f.path, album: 'CloudCut');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved to Gallery (CloudCut album)')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Save failed: $e')));
    }
  }

  Map<String, dynamic> meta(File f) {
    try {
      return jsonDecode(File(f.path.replaceAll('.mp4', '.json')).readAsStringSync()) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('My movies')),
        body: movies.isEmpty
            ? const Center(child: Text('Abhi koi movie nahi'))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: movies.length,
                itemBuilder: (_, i) {
                  final f = movies[i];
                  final m = meta(f);
                  final thumb = File(f.path.replaceAll('.mp4', '.jpg'));
                  final shorts = f.path.contains('9x16');
                  final title = (shorts ? m['shortsTitle'] : m['title']) ?? f.uri.pathSegments.last;
                  final tags = ((shorts ? m['shortsHashtags'] : m['hashtags']) as List? ?? []).join(' ');
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        if (thumb.existsSync())
                          ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(thumb, height: shorts ? 260 : 180, fit: BoxFit.cover)),
                        const SizedBox(height: 8),
                        Text('$title', style: const TextStyle(fontWeight: FontWeight.bold)),
                        Text('${shorts ? 'Shorts 9:16' : 'Movie 16:9'} • ${(f.lengthSync() / 1048576).toStringAsFixed(1)} MB'),
                        const SizedBox(height: 8),
                        Wrap(spacing: 8, children: [
                          FilledButton.icon(onPressed: () => save(f), icon: const Icon(Icons.download), label: const Text('Save')),
                          OutlinedButton.icon(onPressed: () => OpenFilex.open(f.path), icon: const Icon(Icons.play_arrow), label: const Text('Play')),
                          OutlinedButton.icon(
                              onPressed: () => Share.shareXFiles([XFile(f.path)], text: '$title\n$tags'),
                              icon: const Icon(Icons.share),
                              label: const Text('Share')),
                        ]),
                        if (m.isNotEmpty)
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text('Title • Description • Hashtags'),
                            children: [
                              _copy('Title', '$title'),
                              _copy('Description', '${m['description'] ?? ''}'),
                              _copy('Hashtags', tags),
                            ],
                          ),
                        if ((m['report'] as List?)?.isNotEmpty ?? false)
                          ExpansionTile(
                            tilePadding: EdgeInsets.zero,
                            title: const Text('AI report (kya hua har clip ke saath)'),
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: SelectableText((m['report'] as List).join('\n'), style: const TextStyle(fontSize: 12)),
                              ),
                            ],
                          ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton(
                            onPressed: () {
                              for (final ext in ['.mp4', '.jpg', '.json']) {
                                try {
                                  File(f.path.replaceAll('.mp4', ext)).deleteSync();
                                } catch (_) {}
                              }
                              load();
                            },
                            child: const Text('Delete'),
                          ),
                        ),
                      ]),
                    ),
                  );
                },
              ),
      );

  Widget _copy(String label, String text) => ListTile(
        dense: true,
        title: Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        subtitle: Text(text.isEmpty ? '-' : text),
        trailing: IconButton(
          icon: const Icon(Icons.copy, size: 18),
          onPressed: text.isEmpty ? null : () => Clipboard.setData(ClipboardData(text: text)),
        ),
      );
}
