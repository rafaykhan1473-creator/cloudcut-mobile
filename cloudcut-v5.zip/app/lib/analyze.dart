import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'ff.dart';
import 'models.dart';
import 'services.dart';

int _even(double v) => math.max(2, (v / 2).round() * 2);
int _ci(double v, int lo, int hi) {
  final i = v.floor();
  return i < lo ? lo : (i > hi ? hi : i);
}

String _dhash(Uint8List f, int w, int h) {
  final sb = StringBuffer();
  var acc = 0, nb = 0;
  for (var r = 0; r < 8; r++) {
    final y = _ci((r + 0.5) * h / 8, 0, h - 1);
    for (var c = 0; c < 8; c++) {
      final x1 = _ci((c + 0.5) * w / 9, 0, w - 1), x2 = _ci((c + 1.5) * w / 9, 0, w - 1);
      acc = (acc << 1) | (f[y * w + x1] > f[y * w + x2] ? 1 : 0);
      if (++nb == 4) {
        sb.write(acc.toRadixString(16));
        acc = 0;
        nb = 0;
      }
    }
  }
  return sb.toString();
}

Int16List _readWav(String path) {
  final bytes = File(path).readAsBytesSync();
  final bd = ByteData.sublistView(bytes);
  var p = 12;
  while (p + 8 <= bytes.length) {
    final id = String.fromCharCodes(bytes.sublist(p, p + 4));
    final size = bd.getUint32(p + 4, Endian.little);
    if (id == 'data') {
      final start = p + 8;
      var len = math.min(size, bytes.length - start);
      len -= len % 2;
      return Int16List.sublistView(bytes, start, start + len);
    }
    p += 8 + size + (size % 2);
  }
  return Int16List(0);
}

double _log10(double x) => math.log(x) / math.ln10;

/// Ek clip ka poora analysis - 100% on-device (FFmpeg raw frames + Dart math + Whisper + ML Kit).
Future<Clip> analyzeClip(Clip c, String work, Services sv) async {
  final info = await FF.probe(c.path);
  final streams = (info['streams'] as List?) ?? [];
  Map<String, dynamic>? v;
  var audio = false;
  for (final s in streams) {
    if (s is Map<String, dynamic>) {
      if (s['codec_type'] == 'video' && v == null) v = s;
      if (s['codec_type'] == 'audio') audio = true;
    }
  }
  if (v == null) throw Exception('no video stream: ${c.name}');
  var w = (v['width'] as num).toInt(), h = (v['height'] as num).toInt();
  var rot = int.tryParse('${(v['tags'] as Map?)?['rotate'] ?? 0}') ?? 0;
  for (final sd in (v['side_data_list'] as List?) ?? []) {
    if (sd is Map && sd['rotation'] != null) rot = (sd['rotation'] as num).toInt();
  }
  if (rot.abs() % 180 == 90) {
    final t = w;
    w = h;
    h = t;
  }
  final fmt = (info['format'] as Map?) ?? {};
  c.width = w;
  c.height = h;
  c.hasAudio = audio;
  c.duration = double.tryParse('${fmt['duration']}') ?? double.tryParse('${v['duration']}') ?? 0;
  c.creationTime = DateTime.tryParse('${(fmt['tags'] as Map?)?['creation_time']}');
  if (c.duration <= 0) throw Exception('bad duration: ${c.name}');

  // ---- frames: 2 fps, tiny grayscale raw -> sharpness / luma / motion / dHash ----
  final fw = w >= h ? 160 : _even(160.0 * w / h);
  final fh = w >= h ? _even(160.0 * h / w) : 160;
  final raw = '$work/v${c.position}.raw';
  await FF.run(['-i', c.path, '-t', '600', '-vf', 'fps=2,scale=$fw:$fh:flags=bilinear,format=gray', '-an', '-f', 'rawvideo', raw]);
  final bytes = await File(raw).readAsBytes();
  final fs = fw * fh;
  final nFrames = bytes.length ~/ fs;
  final fSharp = <double>[], fLuma = <double>[], fMotion = <double>[];
  Uint8List? prev;
  for (var i = 0; i < nFrames; i++) {
    final f = Uint8List.sublistView(bytes, i * fs, (i + 1) * fs);
    var sum = 0.0, sq = 0.0, cnt = 0, lum = 0;
    for (var y = 1; y < fh - 1; y++) {
      final r = y * fw;
      for (var x = 1; x < fw - 1; x++) {
        final l = 4 * f[r + x] - f[r + x - 1] - f[r + x + 1] - f[r - fw + x] - f[r + fw + x];
        sum += l;
        sq += l * l;
        cnt++;
      }
    }
    for (var k = 0; k < fs; k++) {
      lum += f[k];
    }
    final mean = cnt > 0 ? sum / cnt : 0.0;
    final variance = cnt > 0 ? sq / cnt - mean * mean : 0.0;
    var mot = 0.0;
    if (prev != null) {
      var d = 0;
      for (var k = 0; k < fs; k++) {
        d += (f[k] - prev[k]).abs();
      }
      mot = d / fs / 255.0;
    }
    fSharp.add(math.min(variance / 40.0, 1.0));
    fLuma.add(lum / fs / 255.0);
    fMotion.add(mot);
    c.hashes.add(HashPt(i / 2.0, _dhash(f, fw, fh)));
    prev = Uint8List.fromList(f);
  }
  try {
    File(raw).deleteSync();
  } catch (_) {}

  // ---- audio: RMS per 0.1s -> silence, loudness, gain ----
  final perSecDb = <double>[];
  var activeFrac = 0.0;
  String? wav;
  if (audio) {
    wav = '$work/a${c.position}.wav';
    await FF.run(['-i', c.path, '-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', wav]);
    final pcm = _readWav(wav);
    const win = 1600;
    final nWin = pcm.length ~/ win;
    final dbw = List<double>.filled(nWin, -90.0);
    for (var k = 0; k < nWin; k++) {
      var s = 0.0;
      for (var i = 0; i < win; i++) {
        final x = pcm[k * win + i] / 32768.0;
        s += x * x;
      }
      dbw[k] = 10 * _log10(s / win + 1e-12);
    }
    var runStart = -1;
    for (var k = 0; k <= nWin; k++) {
      final silent = k < nWin && dbw[k] < -40;
      if (silent && runStart < 0) runStart = k;
      if (!silent && runStart >= 0) {
        if ((k - runStart) * 0.1 >= 0.6) c.silences.add([runStart * 0.1, k * 0.1]);
        runStart = -1;
      }
    }
    final active = dbw.where((d) => d >= -40).toList();
    activeFrac = nWin > 0 ? active.length / nWin : 0;
    if (active.isNotEmpty) {
      final speech = active.reduce((a, b) => a + b) / active.length;
      c.gainDb = speech > -55 ? math.max(-10.0, math.min(12.0, -20.0 - speech)) : 0.0;
    }
    for (var s = 0; s * 10 < nWin; s++) {
      final part = dbw.sublist(s * 10, math.min(nWin, s * 10 + 10));
      perSecDb.add(part.reduce((a, b) => a + b) / part.length);
    }
  }

  c.activeFrac = activeFrac;

  // ---- speech (Whisper) ----
  if (wav != null && activeFrac > 0.2 && sv.transcriber != null) {
    final r = await sv.transcriber!.run(wav);
    if (r != null) {
      c.words = r.words;
      c.sentences = r.sentences;
    }
  }
  _rateSentences(c, perSecDb);

  // ---- faces + smile (ML Kit), 1 frame/sec ----
  final nSec = c.duration.ceil();
  final faceRes = <FaceResult>[];
  if (sv.faces != null) {
    try {
      final dir = Directory('$work/f${c.position}')..createSync(recursive: true);
      await FF.run(['-i', c.path, '-t', '120', '-vf', 'fps=1,scale=320:-2', '-q:v', '5', '-frames:v', '120', '${dir.path}/f%03d.jpg']);
      final files = dir.listSync().whereType<File>().toList()..sort((a, b) => a.path.compareTo(b.path));
      for (final f in files) {
        faceRes.add(await sv.faces!.detect(f.path, 320.0));
      }
      dir.deleteSync(recursive: true);
    } catch (_) {}
  }

  // ---- timeline per second ----
  var cxSum = 0.0, cxN = 0;
  for (var s = 0; s < nSec; s++) {
    final st = SecStat();
    final i0 = s * 2, i1 = math.min(nFrames, i0 + 2);
    if (i0 < nFrames) {
      final n = (i1 - i0).toDouble();
      st.luma = 0;
      for (var i = i0; i < i1; i++) {
        st.sharp += fSharp[i] / n;
        st.luma += fLuma[i] / n;
        st.motion += fMotion[i] / n;
      }
    }
    if (s < faceRes.length && faceRes[s].has) {
      st.face = 1;
      st.smile = faceRes[s].smile;
      cxSum += faceRes[s].cx;
      cxN++;
      st.ei = st.smile > 0.5 ? 0.6 : 0.2;
    }
    if (s < perSecDb.length) st.rms = math.max(0.0, math.min(1.0, (perSecDb[s] + 60) / 50));
    c.timeline.add(st);
  }
  double avg(double Function(SecStat) f) => c.timeline.isEmpty ? 0 : c.timeline.map(f).reduce((a, b) => a + b) / c.timeline.length;
  c.faceCx = cxN > 0 ? cxSum / cxN : -1;
  c.faceRatio = avg((t) => t.face);
  c.smileRatio = avg((t) => t.smile);
  c.motion = avg((t) => t.motion);
  c.sharp = avg((t) => t.sharp);
  c.luma = avg((t) => t.luma);
  final exposure = 1 - math.min((c.luma - 0.45).abs() / 0.45, 1.0);
  c.quality = 0.5 * c.sharp + 0.3 * exposure + 0.2 * math.min(h, 1080) / 1080;
  c.action = c.motion > 0.08 ? 'high' : (c.motion > 0.03 ? 'medium' : 'low');
  _fuseEmotion(c, perSecDb);
  return c;
}

void _rateSentences(Clip c, List<double> db) {
  for (final s in c.sentences) {
    final part = db.isEmpty ? <double>[-40] : db.sublist(math.min(db.length - 1, s.s.floor()), math.min(db.length, math.max(s.s.floor() + 1, s.e.ceil())));
    final avg = part.isEmpty ? -40.0 : part.reduce((a, b) => a + b) / part.length;
    final loud = math.max(0.0, math.min(1.0, (avg + 50) / 40));
    final toks = RegExp(r'\w+').allMatches(s.text.toLowerCase()).map((m) => m.group(0)!).toList();
    final uniq = toks.isEmpty ? 0.0 : toks.toSet().length / toks.length;
    final score = 0.35 * math.min((s.e - s.s) / 6, 1.0) + 0.30 * loud + 0.15 * (RegExp(r'[!?]').hasMatch(s.text) ? 1 : 0) + 0.20 * uniq;
    s.important = score >= 0.5 && toks.length >= 4;
    if (s.important) {
      for (final w in c.words) {
        if (w.s >= s.s - 0.05 && w.s <= s.e + 0.05) w.imp = true;
      }
    }
  }
}

/// Emotion (honest): smile (ML Kit) + audio/motion arousal. Sad/fear/surprise ke liye face-emotion model nahi - heuristic hai.
void _fuseEmotion(Clip c, List<double> db) {
  final wps = c.words.length / math.max(c.duration, 1);
  final peak = db.isEmpty ? -60.0 : db.reduce(math.max);
  final arousal = math.max(
      0.0, math.min(1.0, 0.4 * math.min(c.motion / 0.08, 1.0) + 0.3 * math.max(0.0, math.min(1.0, (peak + 30) / 30)) + 0.3 * math.min(wps / 3, 1.0)));
  var label = 'neutral';
  var inten = 0.3;
  if (c.smileRatio > 0.4) {
    label = arousal > 0.55 ? 'excitement' : 'happy';
    inten = math.max(0.6, arousal);
  } else if (arousal > 0.7) {
    label = 'excitement';
    inten = arousal;
  } else if (c.faceRatio > 0.3 && arousal < 0.15 && c.luma < 0.35) {
    label = 'sad';
    inten = 0.4;
  }
  c.emotion = label;
  c.intensity = inten;
}
